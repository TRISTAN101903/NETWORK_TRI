#!/usr/bin/env bash
# Installs the Android command-line SDK (platform, build-tools, platform-tools)
# into GitHub Codespaces so the project can be built headlessly with Gradle —
# no Android Studio needed. Runs once when the Codespace is created.
set -euo pipefail

ANDROID_HOME="/opt/android-sdk"
CMDLINE_VERSION="11076708" # commandlinetools-linux, current stable as of early 2026
CMDLINE_ZIP="commandlinetools-linux-${CMDLINE_VERSION}_latest.zip"

echo "==> Installing Android command-line tools to ${ANDROID_HOME}"
sudo mkdir -p "${ANDROID_HOME}/cmdline-tools"
sudo chown -R "$(whoami)" "${ANDROID_HOME}"

TMP_DIR="$(mktemp -d)"
curl -sSL "https://dl.google.com/android/repository/${CMDLINE_ZIP}" -o "${TMP_DIR}/cmdline-tools.zip"
unzip -q "${TMP_DIR}/cmdline-tools.zip" -d "${TMP_DIR}"
# The zip extracts to a folder named "cmdline-tools"; the sdkmanager expects
# it to live under cmdline-tools/latest/
mv "${TMP_DIR}/cmdline-tools" "${ANDROID_HOME}/cmdline-tools/latest"
rm -rf "${TMP_DIR}"

export ANDROID_HOME
export ANDROID_SDK_ROOT="${ANDROID_HOME}"
export PATH="${ANDROID_HOME}/cmdline-tools/latest/bin:${ANDROID_HOME}/platform-tools:${PATH}"

echo "==> Accepting SDK licenses"
yes | sdkmanager --licenses >/dev/null 2>&1 || true

echo "==> Installing platform-tools, platform 36, build-tools 36"
sdkmanager --install \
  "platform-tools" \
  "platforms;android-36" \
  "build-tools;36.0.0" >/dev/null

echo "==> Persisting environment for future shells in this Codespace"
{
  echo "export ANDROID_HOME=${ANDROID_HOME}"
  echo "export ANDROID_SDK_ROOT=${ANDROID_HOME}"
  echo "export PATH=\"${ANDROID_HOME}/cmdline-tools/latest/bin:${ANDROID_HOME}/platform-tools:\$PATH\""
} >> "${HOME}/.bashrc"

echo "ANDROID_HOME created locally since Codespaces has real internet access, unlike" \
     "the chat sandbox this project was first written in." \
     > "${ANDROID_HOME}/.generated-by-tristan-setup"

echo "local.properties pointing at ${ANDROID_HOME}"
cat > "$(dirname "$0")/../local.properties" <<EOF
sdk.dir=${ANDROID_HOME}
EOF

chmod +x "$(dirname "$0")/../gradlew"
chmod +x "$(dirname "$0")/../build-apk.sh" 2>/dev/null || true

echo "==> Android SDK setup complete."
