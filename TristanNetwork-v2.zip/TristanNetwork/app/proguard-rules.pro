# Keep Room entities
-keep class com.tristan.network.data.local.db.** { *; }
-keepclassmembers class * {
    @androidx.room.* <methods>;
}
-dontwarn kotlinx.coroutines.**
