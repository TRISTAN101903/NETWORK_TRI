package com.tristan.network.ui.components

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tristan.network.ui.theme.CyberCyan
import com.tristan.network.ui.theme.CyberViolet

/**
 * The "Tristan" signature, written in a real handwriting font (Great Vibes, SIL OFL — fetched into
 * assets/fonts/signature.ttf by the Gradle task `fetchSignatureFont` at build time; if the file is
 * missing it falls back to the system cursive face so the app always builds and runs).
 *
 * The signature is "written" left-to-right with a glowing pen tip, followed by a swoosh underline.
 *
 * @param play restart the writing animation whenever this flips to true.
 */
@Composable
fun TristanSignature(
    modifier: Modifier = Modifier,
    color: Color = CyberCyan,
    play: Boolean = true,
    durationMillis: Int = 2000,
    fontSizeSp: Int = 54
) {
    val context = LocalContext.current
    val family = remember(context) { signatureFontFamily(context) }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(play) {
        if (play) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(durationMillis, easing = LinearOutSlowInEasing))
        } else {
            progress.snapTo(0f)
        }
    }

    val p = progress.value
    val brush = Brush.horizontalGradient(listOf(color, CyberViolet))

    Box(modifier = modifier) {
        Text(
            text = "Tristan",
            style = TextStyle(
                brush = brush,
                fontFamily = family,
                fontSize = fontSizeSp.sp,
                shadow = Shadow(color = color.copy(alpha = 0.55f), offset = Offset.Zero, blurRadius = 18f)
            ),
            modifier = Modifier
                .drawWithContent {
                    val edge = size.width * p
                    clipRect(left = 0f, top = 0f, right = edge, bottom = size.height) {
                        this@drawWithContent.drawContent()
                    }
                    if (p > 0.001f && p < 0.999f) {
                        val pen = Offset(edge, size.height * 0.62f)
                        drawCircle(color = color.copy(alpha = 0.95f), radius = 3.dp.toPx(), center = pen)
                        drawCircle(color = color.copy(alpha = 0.25f), radius = 8.dp.toPx(), center = pen)
                    }
                }
                .padding(horizontal = 14.dp, vertical = 4.dp)
        )

        // Swoosh underline, drawn after the name is mostly written.
        Canvas(modifier = Modifier.matchParentSize()) {
            val fp = ((p - 0.6f) / 0.4f).coerceIn(0f, 1f)
            if (fp > 0f) {
                val w = size.width
                val h = size.height
                val path = Path().apply {
                    moveTo(w * 0.08f, h * 0.90f)
                    cubicTo(w * 0.32f, h * 1.02f, w * 0.62f, h * 0.78f, w * 0.96f, h * 0.84f)
                }
                val measure = PathMeasure()
                measure.setPath(path, false)
                val visible = Path()
                measure.getSegment(0f, measure.length * fp, visible, true)
                drawPath(
                    path = visible,
                    brush = Brush.horizontalGradient(listOf(color, CyberViolet)),
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
    }
}

private fun signatureFontFamily(context: Context): FontFamily = try {
    val assets = context.assets
    if (assets.list("fonts")?.contains("signature.ttf") == true) {
        FontFamily(Font(assetManager = assets, path = "fonts/signature.ttf"))
    } else {
        FontFamily.Cursive
    }
} catch (_: Exception) {
    FontFamily.Cursive
}
