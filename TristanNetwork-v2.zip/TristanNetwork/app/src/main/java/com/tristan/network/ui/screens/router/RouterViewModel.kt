package com.tristan.network.ui.screens.router

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

data class RouterUiState(
    val routerAddress: String = "192.168.1.1",
    val username: String = "",
    val password: String = "",
    val isConnecting: Boolean = false,
    val connected: Boolean = false,
    val statusMessage: String? = null
)

/**
 * Lets the user reach their OWN router's admin interface using credentials
 * THEY supply. This never attempts default-password lists, brute-force, or
 * any authentication bypass — it only ever sends the single credential pair
 * the user typed, exactly once per "Connect" tap, via standard HTTP Basic
 * Auth, which is how most consumer router admin pages work. Because router
 * admin APIs vary wildly by vendor, this screen can confirm reachability and
 * authentication, but full client-list / settings parsing requires a
 * vendor-specific integration the user's router vendor would need to publish.
 */
class RouterViewModel : ViewModel() {

    private val _state = MutableStateFlow(RouterUiState())
    val state: StateFlow<RouterUiState> = _state.asStateFlow()

    fun setAddress(value: String) { _state.value = _state.value.copy(routerAddress = value) }
    fun setUsername(value: String) { _state.value = _state.value.copy(username = value) }
    fun setPassword(value: String) { _state.value = _state.value.copy(password = value) }

    fun connect() {
        val s = _state.value
        if (s.username.isBlank() || s.password.isBlank()) {
            _state.value = s.copy(statusMessage = "Enter your router's admin username and password.")
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(isConnecting = true, statusMessage = null)
            val result = withContext(Dispatchers.IO) {
                tryConnect(s.routerAddress, s.username, s.password)
            }
            _state.value = _state.value.copy(
                isConnecting = false,
                connected = result.first,
                statusMessage = result.second
            )
        }
    }

    private fun tryConnect(address: String, user: String, pass: String): Pair<Boolean, String> {
        return try {
            val url = URL("http://$address/")
            val connection = url.openConnection() as HttpURLConnection
            val auth = Base64.getEncoder().encodeToString("$user:$pass".toByteArray())
            connection.setRequestProperty("Authorization", "Basic $auth")
            connection.connectTimeout = 4000
            connection.readTimeout = 4000
            connection.requestMethod = "GET"
            val code = connection.responseCode
            connection.disconnect()
            when (code) {
                in 200..299 -> true to "Connected to router admin interface."
                401, 403 -> false to "Authentication failed — check username/password."
                else -> false to "Router responded with HTTP $code."
            }
        } catch (e: Exception) {
            false to "Could not reach $address: ${e.message}"
        }
    }

    fun disconnect() {
        _state.value = _state.value.copy(connected = false, statusMessage = null)
    }
}
