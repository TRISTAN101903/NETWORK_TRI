package com.tristan.network.ui.navigation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground

@Composable
fun MoreScreen(
    onNavigateRouter: () -> Unit,
    onNavigateLab: () -> Unit,
    onNavigateSettings: () -> Unit,
    onNavigateAnalyzer: () -> Unit,
    onNavigateDevices: () -> Unit,
    onNavigateAudit: () -> Unit
) {
    NetworkParticleBackground {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("More", style = MaterialTheme.typography.displayLarge) }
            item { MoreRow("Network Analyzer", Icons.Filled.Speed, onNavigateAnalyzer) }
            item { MoreRow("Local Devices", Icons.Filled.Devices, onNavigateDevices) }
            item { MoreRow("Security Audit", Icons.Filled.Shield, onNavigateAudit) }
            item { MoreRow("Router Management", Icons.Filled.Router, onNavigateRouter) }
            item { MoreRow("Wi-Fi Security Lab", Icons.Filled.Science, onNavigateLab) }
            item { MoreRow("Settings", Icons.Filled.Settings, onNavigateSettings) }
        }
    }
}

@Composable
private fun MoreRow(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onClick() },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("  $label", style = MaterialTheme.typography.titleMedium)
            }
            Icon(
                Icons.Filled.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
