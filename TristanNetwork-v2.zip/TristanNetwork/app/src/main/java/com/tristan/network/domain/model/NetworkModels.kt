package com.tristan.network.domain.model

/** Result of a single ping round-trip. */
data class PingResult(
    val sequence: Int,
    val timeMs: Double?,
    val success: Boolean,
    val timestamp: Long
)

data class PingSummary(
    val host: String,
    val sent: Int,
    val received: Int,
    val minMs: Double?,
    val avgMs: Double?,
    val maxMs: Double?,
    val packetLossPercent: Double
)

data class DnsLookupResult(
    val host: String,
    val addresses: List<String>,
    val durationMs: Long,
    val success: Boolean,
    val error: String? = null
)

data class HttpCheckResult(
    val url: String,
    val statusCode: Int?,
    val durationMs: Long,
    val success: Boolean,
    val error: String? = null
)

data class TraceHop(
    val hopNumber: Int,
    val address: String?,
    val timeMs: Double?,
    val reached: Boolean
)

data class SpeedTestResult(
    val downloadMbps: Double?,
    val uploadMbps: Double?,
    val latencyMs: Double?,
    val jitterMs: Double?,
    val timestamp: Long
)

/** A device discovered on the local network via legitimate ARP-table / ping-sweep discovery. */
data class LocalDevice(
    val ipAddress: String,
    val macAddress: String?,
    val hostname: String?,
    val vendor: String?,
    val isOnline: Boolean,
    val firstSeen: Long,
    val lastSeen: Long,
    val customName: String? = null,
    val isFavorite: Boolean = false
)
