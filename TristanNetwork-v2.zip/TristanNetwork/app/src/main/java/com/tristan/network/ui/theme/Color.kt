package com.tristan.network.ui.theme

import androidx.compose.ui.graphics.Color

// Core cyan/blue "Liquid Glass / Cyber Network" palette
val CyberCyan = Color(0xFF34E7FF)
val CyberCyanDeep = Color(0xFF00B4D8)
val CyberBlue = Color(0xFF3A7BFF)
val CyberBluePale = Color(0xFF7FD9FF)
val CyberViolet = Color(0xFF7C5CFF)

// Dark "space" backgrounds the glass cards float on
val SpaceBlack = Color(0xFF060B14)
val SpaceDeep = Color(0xFF0A1220)
val SpaceSurface = Color(0xFF0F1B2E)

// Light-mode backdrop
val MistWhite = Color(0xFFF2F7FC)
val MistSurface = Color(0xFFE6F0FA)

// Glass surfaces (alpha applied at use-site, these are the base tints)
val GlassTintDark = Color(0xFF13233B)
val GlassTintLight = Color(0xFFFFFFFF)
val GlassBorderDark = Color(0x33BFEFFF)
val GlassBorderLight = Color(0x66FFFFFF)

// Status
val SignalExcellent = Color(0xFF3DDC97)
val SignalGood = Color(0xFF34E7FF)
val SignalFair = Color(0xFFFFC857)
val SignalPoor = Color(0xFFFF5C7A)

val SecurityOpen = Color(0xFFFF5C7A)
val SecurityWeak = Color(0xFFFFC857)
val SecurityStrong = Color(0xFF3DDC97)

val OnDarkPrimary = Color(0xFFFFFFFF)
val OnDarkSecondary = Color(0xFFE3ECF6)
val OnLightPrimary = Color(0xFF000000)
val OnLightSecondary = Color(0xFF1B2733)
