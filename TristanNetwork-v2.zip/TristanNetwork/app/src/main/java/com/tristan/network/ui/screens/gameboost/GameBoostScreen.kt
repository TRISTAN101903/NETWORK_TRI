package com.tristan.network.ui.screens.gameboost

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.NeonGlassCard
import com.tristan.network.ui.components.RocketTLogo
import com.tristan.network.ui.overlay.GameOverlayService
import com.tristan.network.ui.theme.tristanColors
import com.tristan.network.util.startActivitySafely

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun GameBoostScreen(viewModel: GameBoostViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val state by viewModel.state.collectAsState()
    val overlayEnabled by viewModel.overlayEnabled.collectAsState()
    val fpsTarget by viewModel.fpsTarget.collectAsState()
    val perfMode by viewModel.perfMode.collectAsState()
    val autoDnd by viewModel.autoDnd.collectAsState()
    val trackedPackages by viewModel.trackedPackages.collectAsState()
    val colors = MaterialTheme.tristanColors
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }

    fun overlayGranted() = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)
    fun notificationPolicyGranted(): Boolean {
        val nm = context.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    val notificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        rememberPermissionState(Manifest.permission.POST_NOTIFICATIONS)
    } else null

    LaunchedEffect(Unit) {
        if (notificationPermission?.status?.isGranted == false) {
            notificationPermission?.launchPermissionRequest()
        }
    }

    // Starts/stops the actual foreground overlay service to match the persisted
    // toggle, but only once every permission it needs is actually granted.
    LaunchedEffect(overlayEnabled, state.hasOverlayPermission, state.hasUsageAccess) {
        val serviceIntent = Intent(context, GameOverlayService::class.java)
        if (overlayEnabled && state.hasOverlayPermission && state.hasUsageAccess) {
            try {
                androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)
            } catch (_: Exception) {
                // e.g. background-start restriction — never crash the screen over it.
            }
        } else {
            context.stopService(serviceIntent)
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissions()
                viewModel.loadInstalledGames()
                viewModel.updatePermissionFlags(overlayGranted(), notificationPolicyGranted())
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        viewModel.updatePermissionFlags(overlayGranted(), notificationPolicyGranted())
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    NetworkParticleBackground {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("Game Booster", style = MaterialTheme.typography.displayLarge) }

            item {
                NeonGlassCard {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        RocketTLogo(sizeDp = 64.dp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Bật overlay khi vào game — kéo từ mép trái để xem tốc độ mạng, pin và tuỳ chỉnh FPS.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            item {
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Bật Game Booster", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Tự hiện overlay khi mở một game đã chọn bên dưới",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = overlayEnabled,
                            onCheckedChange = viewModel::setOverlayEnabled,
                            enabled = state.hasUsageAccess && state.hasOverlayPermission
                        )
                    }
                }
            }

            item {
                PermissionRow(
                    title = "Quyền truy cập sử dụng (Usage Access)",
                    detail = "Để biết khi nào một game đang mở ở foreground",
                    granted = state.hasUsageAccess,
                    onGrant = { context.startActivitySafely(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                )
            }
            item {
                PermissionRow(
                    title = "Quyền hiển thị đè (Overlay)",
                    detail = "Để vẽ bảng điều khiển nổi trên game",
                    granted = state.hasOverlayPermission,
                    onGrant = {
                        context.startActivitySafely(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")),
                            fallback = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                        )
                    }
                )
            }
            item {
                PermissionRow(
                    title = "Quyền Không làm phiền (Do Not Disturb)",
                    detail = "Để tự chặn thông báo/popup làm phiền khi đang chơi",
                    granted = state.hasNotificationPolicyAccess,
                    onGrant = { context.startActivitySafely(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                )
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("FPS mục tiêu", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Lưu ý: đây là tần số khung hình overlay của TRISTAN tự yêu cầu cho cửa sổ " +
                                "của chính nó / gợi ý chế độ hiển thị hệ thống — Android không cho phép app " +
                                "ngoài ép buộc FPS của một game khác khi máy chưa root.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(30, 60, 90).forEach { fps ->
                                FilterChip(
                                    selected = fpsTarget == fps,
                                    onClick = { viewModel.setFpsTarget(fps) },
                                    label = { Text("$fps") }
                                )
                            }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Chế độ hiệu năng / pin", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("BALANCED" to "Cân bằng", "PERFORMANCE" to "Hiệu năng cao", "ULTRA_SAVER" to "Tiết kiệm siêu cao")
                                .forEach { (value, label) ->
                                    FilterChip(
                                        selected = perfMode == value,
                                        onClick = { viewModel.setPerfMode(value) },
                                        label = { Text(label) }
                                    )
                                }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Tự bật Không làm phiền khi chơi", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Chặn thông báo/cuộc gọi hiện popup trong lúc chơi game đã chọn",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = autoDnd, onCheckedChange = viewModel::setAutoDnd)
                    }
                }
            }

            item { Text("Chọn game để theo dõi", style = MaterialTheme.typography.titleLarge) }

            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Tìm game / ứng dụng") }
                )
            }

            val filtered = state.installedGames.filter {
                query.isBlank() || it.label.contains(query.trim(), ignoreCase = true)
            }
            val games = filtered.filter { it.isGame }
            val others = filtered.filter { !it.isGame }

            if (games.isNotEmpty()) {
                item { Text("Game", style = MaterialTheme.typography.labelLarge, color = colors.signalGood) }
                items(games, key = { "g_" + it.packageName }) { game ->
                    GameRow(game.label, trackedPackages.contains(game.packageName)) { checked ->
                        viewModel.toggleTrackedGame(game.packageName, checked)
                    }
                }
            }
            if (others.isNotEmpty()) {
                item {
                    Text(
                        "Ứng dụng khác (game cài ngoài CH Play thường nằm ở đây)",
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.signalGood
                    )
                }
                items(others, key = { "a_" + it.packageName }) { app ->
                    GameRow(app.label, trackedPackages.contains(app.packageName)) { checked ->
                        viewModel.toggleTrackedGame(app.packageName, checked)
                    }
                }
            }

            if (state.installedGames.isEmpty()) {
                item {
                    GlassCard {
                        Text(
                            "Chưa đọc được danh sách ứng dụng. Hãy mở lại màn hình này; nếu vẫn trống, " +
                                "cài lại bản APK mới (bản cũ thiếu khai báo quyền xem ứng dụng).",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

@Composable
private fun PermissionRow(title: String, detail: String, granted: Boolean, onGrant: () -> Unit) {
    val colors = MaterialTheme.tristanColors
    GlassCard {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (granted) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                contentDescription = null,
                tint = if (granted) colors.securityStrong else colors.signalFair
            )
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!granted) {
                Button(onClick = onGrant) { Text("Cấp quyền") }
            }
        }
    }
}

@Composable
private fun GameRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    GlassCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
