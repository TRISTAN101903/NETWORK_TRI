package com.tristan.network.ui.components

import androidx.compose.runtime.getValue
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.theme.tristanColors

/** Shimmering skeleton placeholder row, shown while data (scan/device lists) is loading. */
@Composable
fun SkeletonLine(modifier: Modifier = Modifier, height: androidx.compose.ui.unit.Dp = 16.dp) {
    val colors = MaterialTheme.tristanColors
    val transition = rememberInfiniteTransition(label = "skeleton")
    val shimmer by transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmer"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(8.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        colors.glassTint.copy(alpha = 0.4f),
                        colors.glassBorder.copy(alpha = 0.7f),
                        colors.glassTint.copy(alpha = 0.4f)
                    ),
                    start = androidx.compose.ui.geometry.Offset(shimmer * 300f, 0f),
                    end = androidx.compose.ui.geometry.Offset(shimmer * 300f + 300f, 0f)
                )
            )
    ) {}
}

@Composable
fun SkeletonCard(modifier: Modifier = Modifier) {
    GlassCard(modifier = modifier) {
        Column(modifier = Modifier.padding(4.dp)) {
            SkeletonLine(height = 18.dp)
            androidx.compose.foundation.layout.Spacer(Modifier.height(10.dp))
            SkeletonLine(height = 14.dp, modifier = Modifier.fillMaxWidth(0.6f))
            androidx.compose.foundation.layout.Spacer(Modifier.height(6.dp))
            SkeletonLine(height = 14.dp, modifier = Modifier.fillMaxWidth(0.4f))
        }
    }
}
