package com.tristan.network.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.theme.CyberCyan
import com.tristan.network.ui.theme.CyberViolet
import com.tristan.network.ui.theme.tristanColors

/**
 * The core "Liquid Glass" surface used across every screen: a translucent,
 * blurred, lightly-reflective card with a soft border and a subtle top
 * highlight to fake a glass reflection without needing real backdrop blur
 * (which requires API 31+ RenderEffect) — this composable uses RenderEffect
 * when available and gracefully degrades to a flat translucent tint below API 31.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    content: @Composable () -> Unit
) {
    val colors = MaterialTheme.tristanColors
    val shape: Shape = RoundedCornerShape(cornerRadius)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        colors.glassTint.copy(alpha = if (colors.isDark) 0.55f else 0.65f),
                        colors.glassTint.copy(alpha = if (colors.isDark) 0.35f else 0.45f)
                    )
                )
            )
            .glassReflection(shape)
            .glassBorderStroke(colors.glassBorder, shape)
            .padding(18.dp)
    ) {
        content()
    }
}

/** Thin top highlight band to suggest a glass reflection/sheen. */
private fun Modifier.glassReflection(shape: Shape): Modifier = this.then(
    Modifier.background(
        brush = Brush.verticalGradient(
            colors = listOf(Color.White.copy(alpha = 0.10f), Color.Transparent),
            endY = 120f
        ),
        shape = shape
    )
)

private fun Modifier.glassBorderStroke(color: Color, shape: Shape): Modifier =
    this.border(BorderStroke(1.dp, color), shape)

/** A glass card with an extra background blur layer, for hero/dashboard surfaces. */
@Composable
fun BlurredGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 28.dp,
    blurRadius: Dp = 18.dp,
    content: @Composable () -> Unit
) {
    val colors = MaterialTheme.tristanColors
    val shape: Shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .blur(blurRadius)
                .background(colors.glassTint.copy(alpha = 0.4f), shape)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            colors.glassTint.copy(alpha = if (colors.isDark) 0.45f else 0.55f),
                            colors.glassTint.copy(alpha = if (colors.isDark) 0.2f else 0.3f)
                        )
                    ),
                    shape
                )
                .glassBorderStroke(colors.glassBorder, shape)
                .padding(20.dp)
        ) {
            content()
        }
    }
}

/**
 * "Siêu công nghệ" premium surface: a glass card with a slowly rotating neon
 * cyan→violet gradient edge-glow, used for the in-game overlay panel and
 * other flagship/VIP surfaces where the ordinary GlassCard reads as too plain.
 */
@Composable
fun NeonGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    content: @Composable () -> Unit
) {
    val colors = MaterialTheme.tristanColors
    val shape: Shape = RoundedCornerShape(cornerRadius)
    val transition = rememberInfiniteTransition(label = "neonEdge")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                brush = Brush.sweepGradient(
                    0f to CyberCyan.copy(alpha = 0.9f),
                    0.33f to CyberViolet.copy(alpha = 0.9f),
                    0.66f to CyberCyan.copy(alpha = 0.6f),
                    1f to CyberCyan.copy(alpha = 0.9f)
                ),
                shape = shape
            )
            .padding(1.5.dp)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        colors.glassTint.copy(alpha = if (colors.isDark) 0.82f else 0.78f),
                        colors.glassTint.copy(alpha = if (colors.isDark) 0.68f else 0.6f)
                    )
                )
            )
            .glassReflection(shape)
            .rotatingHighlight(sweep, shape)
            .padding(18.dp)
    ) {
        content()
    }
}

/** A faint rotating highlight arc layered over the neon edge for extra shimmer. */
private fun Modifier.rotatingHighlight(angleDeg: Float, shape: Shape): Modifier = this.then(
    Modifier.border(
        BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        shape
    )
)
