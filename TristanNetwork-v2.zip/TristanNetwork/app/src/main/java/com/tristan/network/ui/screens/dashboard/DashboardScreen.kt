package com.tristan.network.ui.screens.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.domain.model.rssiToLevel
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.SecurityBadge
import com.tristan.network.ui.components.SignalBars
import com.tristan.network.ui.components.SignalPulseDot
import com.tristan.network.ui.components.StatusPill
import com.tristan.network.ui.components.WaveformBackground
import com.tristan.network.ui.theme.tristanColors

data class QuickAction(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val onClick: () -> Unit)

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = viewModel(factory = LocalTristanViewModelFactory.current),
    onNavigateScanner: () -> Unit,
    onNavigateAnalyzer: () -> Unit,
    onNavigateDevices: () -> Unit,
    onNavigateAudit: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val colors = MaterialTheme.tristanColors

    NetworkParticleBackground {
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    "Dashboard",
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            item {
                GlassCard {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    state.wifiInfo?.ssid ?: "Not connected",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    state.wifiInfo?.bssid ?: "—",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            state.wifiInfo?.rssiDbm?.let { rssi ->
                                SignalBars(level = rssiToLevel(rssi))
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        WaveformBackground(amplitude = state.wifiInfo?.rssiDbm?.let {
                            ((it + 100) / 50f).coerceIn(0.2f, 1f)
                        } ?: 0.3f)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            state.wifiInfo?.security?.let { SecurityBadge(it) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                SignalPulseDot(
                                    modifier = Modifier.size(10.dp),
                                    color = if (state.internetReachable == true) colors.signalExcellent else colors.signalPoor
                                )
                                Text(
                                    text = when (state.internetReachable) {
                                        true -> "  Internet OK"
                                        false -> "  No Internet"
                                        null -> "  Checking…"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Network Details", style = MaterialTheme.typography.titleMedium)
                        InfoRow("Frequency / Band", state.wifiInfo?.frequencyMhz?.let { "$it MHz" } ?: "—")
                        InfoRow("Channel", state.wifiInfo?.channel?.takeIf { it > 0 }?.toString() ?: "—")
                        InfoRow("Link speed", state.wifiInfo?.linkSpeedMbps?.let { "$it Mbps" } ?: "—")
                        InfoRow("IP address", state.wifiInfo?.ipAddress ?: "—")
                        InfoRow("Gateway", state.wifiInfo?.gateway ?: "—")
                        InfoRow("DNS", state.wifiInfo?.dnsServers?.joinToString() ?: "—")
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickActionButton("Scan", Icons.Filled.Search, Modifier.weight(1f), onNavigateScanner)
                    QuickActionButton("Analyze", Icons.Filled.NetworkCheck, Modifier.weight(1f), onNavigateAnalyzer)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickActionButton("Devices", Icons.Filled.Router, Modifier.weight(1f), onNavigateDevices)
                    QuickActionButton("Audit", Icons.Filled.Shield, Modifier.weight(1f), onNavigateAudit)
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = MaterialTheme.tristanColors
    Button(
        onClick = onClick,
        modifier = modifier.height(56.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = colors.glassTint.copy(alpha = 0.6f),
            contentColor = MaterialTheme.colorScheme.onSurface
        )
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.height(18.dp))
        Spacer(Modifier.height(0.dp))
        Text("  $label")
    }
}
