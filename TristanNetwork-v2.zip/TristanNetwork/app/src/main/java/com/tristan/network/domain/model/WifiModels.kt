package com.tristan.network.domain.model

/** Snapshot of the Wi-Fi network currently connected, as exposed by WifiManager. */
data class CurrentWifiInfo(
    val ssid: String?,
    val bssid: String?,
    val rssiDbm: Int?,
    val linkSpeedMbps: Int?,
    val frequencyMhz: Int?,
    val channel: Int?,
    val ipAddress: String?,
    val gateway: String?,
    val dnsServers: List<String>,
    val security: String?,
    val isConnected: Boolean,
    val isInternetValidated: Boolean
)

/** One access point seen during a Wi-Fi scan. */
data class ScannedNetwork(
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val frequencyMhz: Int,
    val channel: Int,
    val security: String,
    val timestamp: Long
)

enum class SignalLevel { EXCELLENT, GOOD, FAIR, POOR }

fun rssiToLevel(rssi: Int): SignalLevel = when {
    rssi >= -55 -> SignalLevel.EXCELLENT
    rssi >= -67 -> SignalLevel.GOOD
    rssi >= -78 -> SignalLevel.FAIR
    else -> SignalLevel.POOR
}

fun frequencyToChannel(freqMhz: Int): Int = when {
    freqMhz in 2412..2484 -> if (freqMhz == 2484) 14 else (freqMhz - 2412) / 5 + 1
    freqMhz in 5170..5825 -> (freqMhz - 5000) / 5
    freqMhz in 5955..7115 -> (freqMhz - 5950) / 5 + 1 // Wi-Fi 6E
    else -> -1
}
