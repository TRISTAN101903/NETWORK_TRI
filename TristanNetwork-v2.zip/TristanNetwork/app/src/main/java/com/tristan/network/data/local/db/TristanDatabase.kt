package com.tristan.network.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [DeviceEntity::class, ScanHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class TristanDatabase : RoomDatabase() {
    abstract fun deviceDao(): DeviceDao
    abstract fun scanHistoryDao(): ScanHistoryDao

    companion object {
        @Volatile private var instance: TristanDatabase? = null

        fun getInstance(context: Context): TristanDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    TristanDatabase::class.java,
                    "tristan_network.db"
                ).build().also { instance = it }
            }
    }
}
