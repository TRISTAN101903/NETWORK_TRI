package com.tristan.network.ui.screens.audit

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tristan.network.data.network.WifiRepository
import com.tristan.network.domain.model.CurrentWifiInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuditFinding(
    val title: String,
    val passed: Boolean,
    val detail: String,
    val recommendation: String?
)

data class AuditUiState(
    val isRunning: Boolean = false,
    val wifiInfo: CurrentWifiInfo? = null,
    val score: Int = 0,
    val findings: List<AuditFinding> = emptyList()
)

/**
 * Reports on the security POSTURE of the currently-connected network using only
 * what Android's Wi-Fi APIs already expose (encryption type, SSID visibility
 * inference) — it never attempts to recover, guess, or brute-force a password,
 * and never touches any device other than the phone itself.
 */
class AuditViewModel(private val wifiRepository: WifiRepository) : ViewModel() {

    private val _state = MutableStateFlow(AuditUiState())
    val state: StateFlow<AuditUiState> = _state.asStateFlow()

    fun runAudit() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isRunning = true)
            val info = wifiRepository.getCurrentWifiInfo()
            val findings = buildFindings(info)
            val passCount = findings.count { it.passed }
            val score = if (findings.isNotEmpty()) (passCount * 100 / findings.size) else 0
            _state.value = AuditUiState(
                isRunning = false,
                wifiInfo = info,
                score = score,
                findings = findings
            )
        }
    }

    private fun buildFindings(info: CurrentWifiInfo): List<AuditFinding> {
        val security = info.security ?: "Unknown"
        val list = mutableListOf<AuditFinding>()

        list += AuditFinding(
            title = "Encryption type",
            passed = security.contains("WPA3") || security.contains("WPA2"),
            detail = "Current security: $security",
            recommendation = if (security.contains("WPA3") || security.contains("WPA2")) null
            else "Switch your router to WPA2 or WPA3 in its admin settings — avoid WEP or Open networks."
        )

        list += AuditFinding(
            title = "Not an open network",
            passed = !security.equals("Open", ignoreCase = true),
            detail = if (security.equals("Open", ignoreCase = true)) "This network has no password" else "Password required to join",
            recommendation = if (security.equals("Open", ignoreCase = true))
                "Set a strong WPA2/WPA3 password on your router immediately." else null
        )

        // Static, educational checks the app always surfaces regardless of live data,
        // since WPS status / firmware version aren't exposed by Android's Wi-Fi APIs.
        list += AuditFinding(
            title = "WPS",
            passed = false,
            detail = "Android cannot report WPS status directly — check your router's admin page.",
            recommendation = "If you don't use WPS (push-button pairing), disable it in your router settings — it's a common weak point."
        )

        list += AuditFinding(
            title = "Router firmware",
            passed = false,
            detail = "Firmware version isn't available via Android APIs.",
            recommendation = "Log in to your router's admin page and check for firmware updates periodically."
        )

        list += AuditFinding(
            title = "Unknown devices",
            passed = true,
            detail = "Review the Devices tab regularly for anything you don't recognize.",
            recommendation = null
        )

        return list
    }
}
