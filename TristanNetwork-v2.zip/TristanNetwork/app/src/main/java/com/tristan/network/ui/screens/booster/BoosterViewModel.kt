package com.tristan.network.ui.screens.booster

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tristan.network.data.network.BoosterRepository
import com.tristan.network.domain.model.BoosterResult
import com.tristan.network.domain.model.JunkScanResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class BoosterUiState(
    val memory: BoosterResult.MemorySnapshot? = null,
    val isBoosting: Boolean = false,
    val lastTrimResult: BoosterResult.TrimResult? = null,
    val lastCacheClearedBytes: Long? = null,
    val wifiIsOn: Boolean = true,
    val statusMessage: String? = null,
    val hasAllFilesAccess: Boolean = false,
    val isScanningJunk: Boolean = false,
    val junk: JunkScanResult? = null,
    val junkFreedBytes: Long? = null
)

/**
 * Device & Wi-Fi speed boost: RAM trim via the real (OS-arbitrated)
 * ActivityManager API, this app's own cache clear, and a Wi-Fi link
 * refresh. See BoosterRepository for exactly what each action can and
 * can't do on modern Android — this ViewModel doesn't invent numbers
 * beyond what's actually measured.
 */
class BoosterViewModel(private val repository: BoosterRepository) : ViewModel() {

    private val _state = MutableStateFlow(BoosterUiState())
    val state: StateFlow<BoosterUiState> = _state.asStateFlow()

    init {
        refreshMemory()
    }

    fun refreshMemory() {
        _state.value = _state.value.copy(
            memory = repository.memorySnapshot(),
            wifiIsOn = repository.isWifiOn(),
            hasAllFilesAccess = repository.hasAllFilesAccess()
        )
    }

    fun scanJunk() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isScanningJunk = true, junkFreedBytes = null, statusMessage = "Đang quét file rác...")
            val result = repository.scanJunk()
            _state.value = _state.value.copy(
                isScanningJunk = false,
                junk = result,
                statusMessage = if (result.files.isEmpty()) "Không tìm thấy file rác — máy đã sạch"
                else "Tìm thấy ${result.files.size} file rác (${formatBytes(result.totalBytes)})"
            )
        }
    }

    fun deleteJunk() {
        val junk = _state.value.junk ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(isScanningJunk = true, statusMessage = "Đang xoá file rác...")
            val freed = repository.deleteJunk(junk.files)
            _state.value = _state.value.copy(
                isScanningJunk = false,
                junk = null,
                junkFreedBytes = freed,
                statusMessage = "Đã xoá file rác, giải phóng ${formatBytes(freed)}"
            )
        }
    }

    private fun formatBytes(b: Long): String = when {
        b >= 1024L * 1024 * 1024 -> String.format("%.2f GB", b / (1024.0 * 1024 * 1024))
        b >= 1024L * 1024 -> String.format("%.1f MB", b / (1024.0 * 1024))
        b >= 1024L -> String.format("%.0f KB", b / 1024.0)
        else -> "$b B"
    }

    /** Runs the full boost: trim background apps + clear own cache + attempt Wi-Fi refresh. */
    fun runFullBoost() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isBoosting = true, statusMessage = "Đang tối ưu...")
            val trim = repository.trimBackgroundApps()
            val cleared = repository.clearOwnCache()
            repository.attemptWifiReconnect()
            _state.value = _state.value.copy(
                isBoosting = false,
                memory = repository.memorySnapshot(),
                lastTrimResult = trim,
                lastCacheClearedBytes = cleared,
                wifiIsOn = repository.isWifiOn(),
                statusMessage = "Đã dọn ${trim.packagesRequested} ứng dụng nền, RAM trống tăng ~${trim.freedMb}MB, " +
                    "cache Tristan ${formatBytes(cleared)}"
            )
        }
    }

    fun trimRamOnly() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isBoosting = true)
            val trim = repository.trimBackgroundApps()
            _state.value = _state.value.copy(
                isBoosting = false,
                memory = repository.memorySnapshot(),
                lastTrimResult = trim,
                statusMessage = "Đã dọn ${trim.packagesRequested} ứng dụng nền, giải phóng ~${trim.freedMb}MB RAM"
            )
        }
    }

    fun clearCacheOnly() {
        val cleared = repository.clearOwnCache()
        _state.value = _state.value.copy(
            lastCacheClearedBytes = cleared,
            statusMessage = "Đã dọn ${formatBytes(cleared)} bộ nhớ đệm của Tristan Network"
        )
    }
}
