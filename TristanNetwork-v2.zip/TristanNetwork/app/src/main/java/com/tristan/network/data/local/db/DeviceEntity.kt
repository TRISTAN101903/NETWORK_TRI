package com.tristan.network.data.local.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A locally-remembered device: custom name, favorite flag, discovery history. */
@Entity(tableName = "known_devices")
data class DeviceEntity(
    @PrimaryKey val macOrIp: String,
    val lastIp: String,
    val hostname: String?,
    val vendor: String?,
    val customName: String?,
    val isFavorite: Boolean,
    val firstSeen: Long,
    val lastSeen: Long
)
