package com.tristan.network.ui.components

import android.Manifest
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WifiFind
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.tristan.network.R

/**
 * Wraps content that needs Wi-Fi scan results. Android requires location (pre-13)
 * or NEARBY_WIFI_DEVICES (13+) to expose SSID/BSSID in scan results — this gate
 * requests exactly that permission, explains why in plain language, and otherwise
 * stays out of the way.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun WifiPermissionGate(
    content: @Composable () -> Unit
) {
    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        // Some devices still need location for scan results even on Android 13+, so ask for both.
        listOf(Manifest.permission.NEARBY_WIFI_DEVICES, Manifest.permission.ACCESS_FINE_LOCATION)
    } else {
        listOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val state = rememberMultiplePermissionsState(permissions)

    LaunchedEffect(Unit) {
        if (state.permissions.none { it.status.isGranted }) {
            state.launchMultiplePermissionRequest()
        }
    }

    // Any one of the scan permissions is enough to read results.
    if (state.permissions.any { it.status.isGranted }) {
        content()
    } else {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Filled.WifiFind,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
            )
            Spacer(Modifier.height(12.dp))
            Text(
                stringResourceCompat(R.string.perm_rationale_title),
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(8.dp))
            Text(
                stringResourceCompat(R.string.perm_rationale_body),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { state.launchMultiplePermissionRequest() }) {
                Text(stringResourceCompat(R.string.perm_grant))
            }
        }
    }
}

@Composable
private fun stringResourceCompat(id: Int): String = androidx.compose.ui.res.stringResource(id)
