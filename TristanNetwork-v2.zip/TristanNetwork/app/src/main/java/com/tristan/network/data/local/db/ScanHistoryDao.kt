package com.tristan.network.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanHistoryDao {
    @Insert
    suspend fun insertAll(entities: List<ScanHistoryEntity>)

    @Query("SELECT * FROM scan_history ORDER BY timestamp DESC LIMIT 500")
    fun observeRecent(): Flow<List<ScanHistoryEntity>>

    @Query("SELECT * FROM scan_history WHERE bssid = :bssid ORDER BY timestamp DESC LIMIT 100")
    fun observeForBssid(bssid: String): Flow<List<ScanHistoryEntity>>

    @Query("DELETE FROM scan_history WHERE timestamp < :olderThan")
    suspend fun pruneOlderThan(olderThan: Long)
}
