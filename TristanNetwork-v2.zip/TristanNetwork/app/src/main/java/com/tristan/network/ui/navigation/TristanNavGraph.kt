package com.tristan.network.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.overlay.GameOverlayService
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tristan.network.ui.screens.analyzer.AnalyzerScreen
import com.tristan.network.ui.screens.audit.AuditScreen
import com.tristan.network.ui.screens.booster.BoosterScreen
import com.tristan.network.ui.screens.dashboard.DashboardScreen
import com.tristan.network.ui.screens.devices.DevicesScreen
import com.tristan.network.ui.screens.gameboost.GameBoostScreen
import com.tristan.network.ui.screens.lab.LabScreen
import com.tristan.network.ui.screens.router.RouterScreen
import com.tristan.network.ui.screens.scanner.ScannerScreen
import com.tristan.network.ui.screens.settings.SettingsScreen

sealed class TristanDestination(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    data object Dashboard : TristanDestination("dashboard", "Dashboard", Icons.Filled.NetworkCheck)
    data object Scanner : TristanDestination("scanner", "Scanner", Icons.Filled.Search)
    data object Analyzer : TristanDestination("analyzer", "Analyzer", Icons.Filled.Speed)
    data object Devices : TristanDestination("devices", "Devices", Icons.Filled.Router)
    data object Audit : TristanDestination("audit", "Audit", Icons.Filled.Shield)
    data object More : TristanDestination("more", "More", Icons.Filled.MoreHoriz)
    data object Router : TristanDestination("router_mgmt", "Router", Icons.Filled.Router)
    data object Lab : TristanDestination("lab", "Lab", Icons.Filled.Shield)
    data object Settings : TristanDestination("settings", "Settings", Icons.Filled.MoreHoriz)
    data object Booster : TristanDestination("booster", "Tăng tốc", Icons.Filled.RocketLaunch)
    data object GameBoost : TristanDestination("game_boost", "Game Booster", Icons.Filled.SportsEsports)
}

private val bottomBarDestinations = listOf(
    TristanDestination.Dashboard,
    TristanDestination.Scanner,
    TristanDestination.Booster,
    TristanDestination.GameBoost,
    TristanDestination.More
)

@Composable
fun TristanNavGraph() {
    val navController = rememberNavController()
    val context = LocalContext.current
    var showExitDialog by remember { mutableStateOf(false) }
    val rootEntry by navController.currentBackStackEntryAsState()

    // Back on the home screen asks before leaving instead of silently dropping out.
    BackHandler(enabled = rootEntry?.destination?.route == TristanDestination.Dashboard.route) {
        showExitDialog = true
    }

    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        bottomBar = {
            NavigationBar(containerColor = androidx.compose.ui.graphics.Color.Transparent) {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = backStackEntry?.destination

                bottomBarDestinations.forEach { dest ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = dest.label) },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
        NavHost(
            navController = navController,
            startDestination = TristanDestination.Dashboard.route,
            modifier = Modifier,
            enterTransition = {
                slideInHorizontally(animationSpec = tween(320)) { it / 4 } + fadeIn(tween(320))
            },
            exitTransition = {
                fadeOut(tween(200))
            },
            popEnterTransition = {
                fadeIn(tween(320))
            },
            popExitTransition = {
                slideOutHorizontally(animationSpec = tween(320)) { it / 4 } + fadeOut(tween(200))
            }
        ) {
            composable(TristanDestination.Dashboard.route) {
                DashboardScreen(
                    onNavigateScanner = { navController.navigate(TristanDestination.Scanner.route) },
                    onNavigateAnalyzer = { navController.navigate(TristanDestination.Analyzer.route) },
                    onNavigateDevices = { navController.navigate(TristanDestination.Devices.route) },
                    onNavigateAudit = { navController.navigate(TristanDestination.Audit.route) }
                )
            }
            composable(TristanDestination.Scanner.route) { ScannerScreen() }
            composable(TristanDestination.Analyzer.route) { AnalyzerScreen() }
            composable(TristanDestination.Devices.route) { DevicesScreen() }
            composable(TristanDestination.Audit.route) { AuditScreen() }
            composable(TristanDestination.Router.route) { RouterScreen() }
            composable(TristanDestination.Lab.route) { LabScreen() }
            composable(TristanDestination.Settings.route) { SettingsScreen() }
            composable(TristanDestination.Booster.route) { BoosterScreen() }
            composable(TristanDestination.GameBoost.route) { GameBoostScreen() }
            composable(TristanDestination.More.route) {
                MoreScreen(
                    onNavigateRouter = { navController.navigate(TristanDestination.Router.route) },
                    onNavigateLab = { navController.navigate(TristanDestination.Lab.route) },
                    onNavigateSettings = { navController.navigate(TristanDestination.Settings.route) },
                    onNavigateAnalyzer = { navController.navigate(TristanDestination.Analyzer.route) },
                    onNavigateDevices = { navController.navigate(TristanDestination.Devices.route) },
                    onNavigateAudit = { navController.navigate(TristanDestination.Audit.route) }
                )
            }
        }

        // Always-visible exit button (top-right).
        IconButton(
            onClick = { showExitDialog = true },
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 6.dp).size(36.dp)
        ) {
            Icon(
                Icons.Filled.PowerSettingsNew,
                contentDescription = "Thoát ứng dụng",
                tint = MaterialTheme.colorScheme.onBackground
            )
        }
        }
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text("Thoát Tristan Network?") },
            text = { Text("Ứng dụng sẽ đóng hẳn và Game Booster đang chạy nền cũng tắt. Lần sau mở lại, Game Booster tự bật lại nếu bạn đã bật.") },
            confirmButton = {
                TextButton(onClick = {
                    showExitDialog = false
                    try {
                        context.stopService(android.content.Intent(context, GameOverlayService::class.java))
                    } catch (_: Exception) {
                    }
                    var c: android.content.Context? = context
                    while (c is android.content.ContextWrapper) {
                        if (c is android.app.Activity) {
                            c.finishAndRemoveTask()
                            break
                        }
                        c = c.baseContext
                    }
                }) { Text("Thoát") }
            },
            dismissButton = {
                TextButton(onClick = { showExitDialog = false }) { Text("Ở lại") }
            }
        )
    }
}
