package com.tristan.network.ui.screens.analyzer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tristan.network.data.local.datastore.SettingsDataStore
import com.tristan.network.data.network.NetworkAnalyzer
import com.tristan.network.domain.model.DnsLookupResult
import com.tristan.network.domain.model.HttpCheckResult
import com.tristan.network.domain.model.PingResult
import com.tristan.network.domain.model.PingSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class AnalyzerUiState(
    val target: String = "8.8.8.8",
    val isPinging: Boolean = false,
    val pingResults: List<PingResult> = emptyList(),
    val pingSummary: PingSummary? = null,
    val jitterMs: Double? = null,
    val dnsResult: DnsLookupResult? = null,
    val httpResult: HttpCheckResult? = null,
    val isDownloadTesting: Boolean = false,
    val downloadMbps: Double? = null
)

class AnalyzerViewModel(
    private val analyzer: NetworkAnalyzer,
    private val settings: SettingsDataStore
) : ViewModel() {

    private val _state = MutableStateFlow(AnalyzerUiState())
    val state: StateFlow<AnalyzerUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val target = settings.pingTarget.first()
            _state.value = _state.value.copy(target = target)
        }
    }

    fun setTarget(target: String) {
        _state.value = _state.value.copy(target = target)
    }

    fun runPing() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isPinging = true, pingResults = emptyList(), pingSummary = null)
            val results = mutableListOf<PingResult>()
            analyzer.pingStream(_state.value.target, count = 12).collect { result ->
                results.add(result)
                _state.value = _state.value.copy(pingResults = results.toList())
            }
            _state.value = _state.value.copy(
                isPinging = false,
                pingSummary = analyzer.summarize(_state.value.target, results),
                jitterMs = analyzer.jitter(results)
            )
        }
    }

    fun runDnsLookup(host: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(dnsResult = analyzer.dnsLookup(host))
        }
    }

    fun runHttpCheck(url: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(httpResult = analyzer.httpCheck(url))
        }
    }

    fun runDownloadTest() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isDownloadTesting = true, downloadMbps = null)
            val url = settings.speedTestUrl.first()
            val mbps = analyzer.measureDownloadMbps(url)
            _state.value = _state.value.copy(isDownloadTesting = false, downloadMbps = mbps)
        }
    }
}
