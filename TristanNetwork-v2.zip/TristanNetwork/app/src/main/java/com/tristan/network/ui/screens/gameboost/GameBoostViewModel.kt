package com.tristan.network.ui.screens.gameboost

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tristan.network.data.local.datastore.SettingsDataStore
import com.tristan.network.data.network.GameDetector
import com.tristan.network.domain.model.InstalledGame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class GameBoostUiState(
    val installedGames: List<InstalledGame> = emptyList(),
    val hasUsageAccess: Boolean = false,
    val hasOverlayPermission: Boolean = false,
    val hasNotificationPolicyAccess: Boolean = false
)

/**
 * Settings/setup screen for the in-game overlay: which special permissions
 * are granted, which installed games are tracked, and the default FPS
 * target / performance mode / auto-DND preference the overlay will use.
 */
class GameBoostViewModel(
    private val gameDetector: GameDetector,
    private val settings: SettingsDataStore
) : ViewModel() {

    private val _state = MutableStateFlow(GameBoostUiState())
    val state: StateFlow<GameBoostUiState> = _state.asStateFlow()

    val overlayEnabled: StateFlow<Boolean> = settings.gameOverlayEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val fpsTarget: StateFlow<Int> = settings.gameFpsTarget
        .stateIn(viewModelScope, SharingStarted.Eagerly, 60)
    val perfMode: StateFlow<String> = settings.gamePerfMode
        .stateIn(viewModelScope, SharingStarted.Eagerly, "BALANCED")
    val autoDnd: StateFlow<Boolean> = settings.gameAutoDnd
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val trackedPackages: StateFlow<Set<String>> = settings.gameTrackedPackages
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    init {
        refreshPermissions()
        loadInstalledGames()
    }

    fun refreshPermissions() {
        _state.value = _state.value.copy(
            hasUsageAccess = gameDetector.hasUsageAccess()
        )
    }

    fun updatePermissionFlags(overlayGranted: Boolean, notificationPolicyGranted: Boolean) {
        _state.value = _state.value.copy(
            hasOverlayPermission = overlayGranted,
            hasNotificationPolicyAccess = notificationPolicyGranted
        )
    }

    fun loadInstalledGames() {
        viewModelScope.launch {
            val games = try {
                withContext(Dispatchers.Default) { gameDetector.listInstalledGames() }
            } catch (_: Exception) {
                emptyList()
            }
            _state.value = _state.value.copy(installedGames = games)
        }
    }

    fun setOverlayEnabled(enabled: Boolean) {
        viewModelScope.launch { settings.setGameOverlayEnabled(enabled) }
    }

    fun setFpsTarget(fps: Int) {
        viewModelScope.launch { settings.setGameFpsTarget(fps) }
    }

    fun setPerfMode(mode: String) {
        viewModelScope.launch { settings.setGamePerfMode(mode) }
    }

    fun setAutoDnd(enabled: Boolean) {
        viewModelScope.launch { settings.setGameAutoDnd(enabled) }
    }

    fun toggleTrackedGame(packageName: String, track: Boolean) {
        viewModelScope.launch {
            if (track) settings.addTrackedGamePackage(packageName)
            else settings.removeTrackedGamePackage(packageName)
        }
    }
}
