package com.tristan.network

import android.content.Context
import com.tristan.network.data.local.datastore.SettingsDataStore
import com.tristan.network.data.local.db.TristanDatabase
import com.tristan.network.data.network.BoosterRepository
import com.tristan.network.data.network.GameDetector
import com.tristan.network.data.network.LocalDeviceDiscovery
import com.tristan.network.data.network.NetworkAnalyzer
import com.tristan.network.data.network.WifiRepository
import com.tristan.network.data.repository.DeviceRepository
import com.tristan.network.data.repository.ScanHistoryRepository

/** Minimal manual DI container — avoids pulling in Hilt/Dagger for a single-module app. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val database by lazy { TristanDatabase.getInstance(appContext) }

    val wifiRepository by lazy { WifiRepository(appContext) }
    val networkAnalyzer by lazy { NetworkAnalyzer() }
    val localDeviceDiscovery by lazy { LocalDeviceDiscovery() }
    val settingsDataStore by lazy { SettingsDataStore(appContext) }
    val boosterRepository by lazy { BoosterRepository(appContext) }
    val gameDetector by lazy { GameDetector(appContext) }

    val deviceRepository by lazy { DeviceRepository(database.deviceDao(), localDeviceDiscovery) }
    val scanHistoryRepository by lazy { ScanHistoryRepository(database.scanHistoryDao()) }
}
