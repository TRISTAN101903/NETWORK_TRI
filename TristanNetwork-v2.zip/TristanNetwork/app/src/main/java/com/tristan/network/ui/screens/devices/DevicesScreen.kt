package com.tristan.network.ui.screens.devices

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.domain.model.LocalDevice
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.RadarScanAnimation
import com.tristan.network.ui.components.SignalPulseDot
import com.tristan.network.ui.components.WifiPermissionGate
import com.tristan.network.ui.theme.tristanColors

@Composable
fun DevicesScreen(viewModel: DevicesViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val state by viewModel.state.collectAsState()
    val colors = MaterialTheme.tristanColors

    NetworkParticleBackground {
        WifiPermissionGate {
            Column(Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Devices", style = MaterialTheme.typography.displayLarge)
                    TextButton(onClick = viewModel::scan) {
                        Text(if (state.isScanning) "Scanning…" else "Rescan")
                    }
                }

                if (state.isScanning && state.devices.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RadarScanAnimation()
                        Spacer(Modifier.height(12.dp))
                        Text("Discovering devices on your network…", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(state.devices, key = { it.macAddress ?: it.ipAddress }) { device ->
                            DeviceRow(device, onToggleFavorite = { viewModel.toggleFavorite(device) })
                        }
                        item { Spacer(Modifier.height(40.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceRow(device: LocalDevice, onToggleFavorite: () -> Unit) {
    val colors = MaterialTheme.tristanColors
    GlassCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    device.customName ?: device.hostname ?: device.ipAddress,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    "${device.ipAddress}${device.macAddress?.let { " · $it" } ?: ""}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (device.isOnline) {
                    SignalPulseDot(
                        modifier = Modifier.size(10.dp),
                        color = colors.signalExcellent
                    )
                }
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        if (device.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (device.isFavorite) colors.signalFair else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
