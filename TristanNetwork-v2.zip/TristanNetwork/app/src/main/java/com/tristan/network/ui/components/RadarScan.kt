package com.tristan.network.ui.components

import androidx.compose.runtime.getValue
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.theme.tristanColors
import kotlin.math.cos
import kotlin.math.sin

/**
 * Radar / sweep-scan loading animation used while a Wi-Fi or network scan is running.
 */
@Composable
fun RadarScanAnimation(
    modifier: Modifier = Modifier,
    sizeDp: androidx.compose.ui.unit.Dp = 160.dp
) {
    val colors = MaterialTheme.tristanColors
    val transition = rememberInfiniteTransition(label = "radar")
    val sweepAngle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    Canvas(modifier = modifier.size(sizeDp)) {
        val radius = size.minDimension / 2f
        val center = Offset(size.width / 2f, size.height / 2f)

        // Concentric rings
        for (i in 1..3) {
            drawCircle(
                color = colors.signalGood.copy(alpha = 0.18f),
                radius = radius * (i / 3f),
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )
        }

        // Expanding pulse ring
        drawCircle(
            color = colors.signalGood.copy(alpha = (1f - pulse) * 0.5f),
            radius = radius * pulse,
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )

        // Sweep gradient wedge
        rotate(sweepAngle, center) {
            drawArc(
                brush = Brush.sweepGradient(
                    0f to Color.Transparent,
                    0.85f to Color.Transparent,
                    1f to colors.signalGood.copy(alpha = 0.55f),
                    center = center
                ),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = true,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
            )
        }

        // Sweep line
        val angleRad = Math.toRadians(sweepAngle.toDouble())
        val end = Offset(
            x = center.x + radius * cos(angleRad).toFloat(),
            y = center.y + radius * sin(angleRad).toFloat()
        )
        drawLine(
            color = colors.signalGood,
            start = center,
            end = end,
            strokeWidth = 2.dp.toPx()
        )

        // Center dot
        drawCircle(color = colors.signalGood, radius = 4.dp.toPx(), center = center)
    }
}
