package com.tristan.network.ui.screens.scanner

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.domain.model.ScannedNetwork
import com.tristan.network.domain.model.rssiToLevel
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.RadarScanAnimation
import com.tristan.network.ui.components.SecurityBadge
import com.tristan.network.ui.components.SignalBars
import com.tristan.network.ui.components.WifiPermissionGate
import com.tristan.network.ui.theme.tristanColors
import com.tristan.network.util.startActivitySafely

@Composable
fun ScannerScreen(viewModel: ScannerViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val state by viewModel.state.collectAsState()
    val colors = MaterialTheme.tristanColors
    val context = LocalContext.current

    // Re-check Wi-Fi / Location switches and rescan whenever the user comes back to the app.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshEnvironment()
                viewModel.rescan()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    NetworkParticleBackground {
        WifiPermissionGate {
            // Permission has just been granted (or was already) -> make sure a scan really runs now.
            LaunchedEffect(Unit) { viewModel.rescan() }

            Column(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Wi-Fi Scanner", style = MaterialTheme.typography.displayLarge)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = state.sortMode == SortMode.SIGNAL,
                            onClick = { viewModel.setSortMode(SortMode.SIGNAL) },
                            label = { Text("Signal") }
                        )
                        FilterChip(
                            selected = state.sortMode == SortMode.CHANNEL,
                            onClick = { viewModel.setSortMode(SortMode.CHANNEL) },
                            label = { Text("Channel") }
                        )
                        FilterChip(
                            selected = state.sortMode == SortMode.NAME,
                            onClick = { viewModel.setSortMode(SortMode.NAME) },
                            label = { Text("Name") }
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = viewModel::rescan, enabled = !state.isScanning) {
                        Text(if (state.isScanning) "Đang quét..." else "Quét lại")
                    }
                }

                if (!state.wifiEnabled) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        GlassCard {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Wi-Fi đang tắt — hãy bật Wi-Fi để quét.", color = colors.signalFair)
                                Button(onClick = {
                                    context.startActivitySafely(
                                        Intent(Settings.Panel.ACTION_WIFI),
                                        fallback = Intent(Settings.ACTION_WIFI_SETTINGS)
                                    )
                                }) { Text("Bật Wi-Fi") }
                            }
                        }
                    }
                }
                if (!state.locationEnabled) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        GlassCard {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    "Android chỉ trả kết quả quét Wi-Fi khi Vị trí (Location) của máy đang bật. " +
                                        "App không lưu hay gửi vị trí của bạn.",
                                    color = colors.signalFair
                                )
                                Button(onClick = {
                                    context.startActivitySafely(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                                }) { Text("Bật Vị trí") }
                            }
                        }
                    }
                }

                state.suggestedChannel24?.let { ch ->
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                        GlassCard {
                            Text(
                                "Gợi ý: kênh 2.4 GHz ít nhiễu nhất quanh bạn là kênh $ch " +
                                    "(${state.networks.size} mạng đang thấy).",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }

                if (state.isScanning && state.networks.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RadarScanAnimation()
                        Spacer(Modifier.height(12.dp))
                        Text("Đang quét mạng Wi-Fi…", style = MaterialTheme.typography.bodyMedium)
                    }
                } else if (state.networks.isEmpty()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "Chưa thấy mạng nào. Kiểm tra Wi-Fi và Vị trí đã bật, rồi bấm \"Quét lại\".",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(state.networks, key = { it.bssid.ifBlank { it.ssid } + it.frequencyMhz }) { network ->
                            NetworkRow(network, isConnected = network.bssid.isNotBlank() && network.bssid == state.connectedBssid)
                        }
                        item { Spacer(Modifier.height(40.dp)) }
                    }
                }
            }
        }
    }
}

private fun bandOf(freqMhz: Int): String = when {
    freqMhz < 3000 -> "2.4 GHz"
    freqMhz < 5900 -> "5 GHz"
    else -> "6 GHz"
}

@Composable
private fun NetworkRow(network: ScannedNetwork, isConnected: Boolean) {
    val colors = MaterialTheme.tristanColors
    GlassCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(network.ssid, style = MaterialTheme.typography.titleMedium)
                if (isConnected) {
                    Text("● Đang kết nối", style = MaterialTheme.typography.labelSmall, color = colors.securityStrong)
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    "${bandOf(network.frequencyMhz)} · Ch ${network.channel} · ${network.frequencyMhz} MHz · ${network.rssiDbm} dBm",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                SecurityBadge(network.security)
            }
            SignalBars(level = rssiToLevel(network.rssiDbm))
        }
    }
}
