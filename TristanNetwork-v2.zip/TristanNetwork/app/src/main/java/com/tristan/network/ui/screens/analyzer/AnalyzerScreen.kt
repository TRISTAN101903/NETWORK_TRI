package com.tristan.network.ui.screens.analyzer

import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.WaveformBackground
import java.util.Locale

@Composable
fun AnalyzerScreen(viewModel: AnalyzerViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val state by viewModel.state.collectAsState()

    NetworkParticleBackground {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Text("Network Analyzer", style = MaterialTheme.typography.displayLarge) }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Ping / Latency", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = state.target,
                            onValueChange = viewModel::setTarget,
                            label = { Text("Host (e.g. gateway IP)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        WaveformBackground(
                            amplitude = state.pingSummary?.avgMs?.let { (1.0 - (it / 300.0)).coerceIn(0.1, 1.0).toFloat() } ?: 0.4f
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Metric("Min", state.pingSummary?.minMs?.formatMs())
                            Metric("Avg", state.pingSummary?.avgMs?.formatMs())
                            Metric("Max", state.pingSummary?.maxMs?.formatMs())
                            Metric("Loss", state.pingSummary?.packetLossPercent?.let { "%.0f%%".format(it) })
                        }
                        Button(onClick = viewModel::runPing, enabled = !state.isPinging) {
                            if (state.isPinging) {
                                CircularProgressIndicator(modifier = Modifier.height(16.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.height(0.dp))
                                Text("  Pinging…")
                            } else {
                                Text("Start Ping Test")
                            }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("DNS Lookup", style = MaterialTheme.typography.titleMedium)
                        var host by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("google.com") }
                        OutlinedTextField(
                            value = host,
                            onValueChange = { host = it },
                            label = { Text("Hostname") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Button(onClick = { viewModel.runDnsLookup(host) }) { Text("Resolve") }
                        state.dnsResult?.let { r ->
                            Text(
                                if (r.success) "${r.addresses.joinToString()} (${r.durationMs} ms)" else "Failed: ${r.error}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("HTTP/HTTPS Connectivity", style = MaterialTheme.typography.titleMedium)
                        var url by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("https://www.google.com") }
                        OutlinedTextField(
                            value = url,
                            onValueChange = { url = it },
                            label = { Text("URL") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Button(onClick = { viewModel.runHttpCheck(url) }) { Text("Check") }
                        state.httpResult?.let { r ->
                            Text(
                                if (r.success) "HTTP ${r.statusCode} · ${r.durationMs} ms" else "Failed: ${r.error}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Download Speed", style = MaterialTheme.typography.titleMedium)
                        Text(
                            state.downloadMbps?.let { "%.1f Mbps".format(it) } ?: "—",
                            style = MaterialTheme.typography.displayLarge
                        )
                        Button(onClick = viewModel::runDownloadTest, enabled = !state.isDownloadTesting) {
                            Text(if (state.isDownloadTesting) "Testing…" else "Run Speed Test")
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

@Composable
private fun Metric(label: String, value: String?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value ?: "—", style = MaterialTheme.typography.titleMedium)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun Double.formatMs(): String = String.format(Locale.US, "%.0f ms", this)
