package com.tristan.network.data.network

import com.tristan.network.domain.model.DnsLookupResult
import com.tristan.network.domain.model.HttpCheckResult
import com.tristan.network.domain.model.PingResult
import com.tristan.network.domain.model.PingSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import kotlin.math.sqrt

/**
 * Network diagnostics built entirely on standard, permission-free Android/Java
 * networking APIs (InetAddress, HttpURLConnection). No raw sockets, no ICMP
 * crafting, no third-party probing of networks the user doesn't control —
 * this only ever talks to a host the user explicitly enters (e.g. their own
 * gateway IP) or public DNS/HTTP endpoints, same as any browser would.
 */
class NetworkAnalyzer {

    /** Emits one [PingResult] per attempt via ICMP-echo-like reachability check. */
    fun pingStream(host: String, count: Int = 10, timeoutMs: Int = 1500): Flow<PingResult> = flow {
        for (seq in 1..count) {
            val start = System.currentTimeMillis()
            val reachable = try {
                val addr = InetAddress.getByName(host)
                addr.isReachable(timeoutMs)
            } catch (_: Exception) {
                false
            }
            val elapsed = (System.currentTimeMillis() - start).toDouble()
            emit(
                PingResult(
                    sequence = seq,
                    timeMs = if (reachable) elapsed else null,
                    success = reachable,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }.flowOn(Dispatchers.IO)

    fun summarize(host: String, results: List<PingResult>): PingSummary {
        val times = results.mapNotNull { it.timeMs }
        return PingSummary(
            host = host,
            sent = results.size,
            received = times.size,
            minMs = times.minOrNull(),
            avgMs = if (times.isNotEmpty()) times.average() else null,
            maxMs = times.maxOrNull(),
            packetLossPercent = if (results.isNotEmpty()) {
                (1.0 - times.size.toDouble() / results.size) * 100.0
            } else 0.0
        )
    }

    fun jitter(results: List<PingResult>): Double? {
        val times = results.mapNotNull { it.timeMs }
        if (times.size < 2) return null
        val diffs = times.zipWithNext { a, b -> kotlin.math.abs(b - a) }
        return diffs.average()
    }

    suspend fun dnsLookup(host: String): DnsLookupResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        try {
            val addresses = InetAddress.getAllByName(host).map { it.hostAddress ?: "" }
            DnsLookupResult(
                host = host,
                addresses = addresses,
                durationMs = System.currentTimeMillis() - start,
                success = true
            )
        } catch (e: Exception) {
            DnsLookupResult(
                host = host,
                addresses = emptyList(),
                durationMs = System.currentTimeMillis() - start,
                success = false,
                error = e.message
            )
        }
    }

    suspend fun httpCheck(url: String, timeoutMs: Int = 5000): HttpCheckResult =
        withContext(Dispatchers.IO) {
            val start = System.currentTimeMillis()
            var connection: HttpURLConnection? = null
            try {
                val fullUrl = if (!url.startsWith("http")) "https://$url" else url
                connection = (URL(fullUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = timeoutMs
                    readTimeout = timeoutMs
                    requestMethod = "HEAD"
                    instanceFollowRedirects = true
                }
                val code = connection.responseCode
                HttpCheckResult(
                    url = fullUrl,
                    statusCode = code,
                    durationMs = System.currentTimeMillis() - start,
                    success = code in 200..399
                )
            } catch (e: Exception) {
                HttpCheckResult(
                    url = url,
                    statusCode = null,
                    durationMs = System.currentTimeMillis() - start,
                    success = false,
                    error = e.message
                )
            } finally {
                connection?.disconnect()
            }
        }

    /**
     * Lightweight download-throughput check using a public, size-known test
     * endpoint-free approach: downloads a small payload from a URL the user
     * configures (default: a well-known speed-test-friendly CDN file) and
     * measures elapsed time. No proprietary speed-test protocol is used.
     */
    suspend fun measureDownloadMbps(url: String, timeoutMs: Int = 15000): Double? =
        withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = timeoutMs
                    readTimeout = timeoutMs
                    requestMethod = "GET"
                }
                val start = System.currentTimeMillis()
                var totalBytes = 0L
                connection.inputStream.use { stream ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (stream.read(buffer).also { read = it } != -1) {
                        totalBytes += read
                    }
                }
                val elapsedSec = (System.currentTimeMillis() - start) / 1000.0
                if (elapsedSec <= 0) return@withContext null
                val mbps = (totalBytes * 8.0 / 1_000_000.0) / elapsedSec
                mbps
            } catch (_: Exception) {
                null
            } finally {
                connection?.disconnect()
            }
        }
}
