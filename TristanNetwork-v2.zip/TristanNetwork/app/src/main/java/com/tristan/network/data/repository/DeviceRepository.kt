package com.tristan.network.data.repository

import com.tristan.network.data.local.db.DeviceDao
import com.tristan.network.data.local.db.DeviceEntity
import com.tristan.network.data.network.LocalDeviceDiscovery
import com.tristan.network.domain.model.LocalDevice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class DeviceRepository(
    private val dao: DeviceDao,
    private val discovery: LocalDeviceDiscovery
) {
    fun observeKnownDevices(): Flow<List<LocalDevice>> = dao.observeAll().map { list ->
        list.map {
            LocalDevice(
                ipAddress = it.lastIp,
                macAddress = it.macOrIp.takeIf { k -> k.contains(":") },
                hostname = it.hostname,
                vendor = it.vendor,
                isOnline = false,
                firstSeen = it.firstSeen,
                lastSeen = it.lastSeen,
                customName = it.customName,
                isFavorite = it.isFavorite
            )
        }
    }

    fun discoverLive() = discovery.discoverFlow()

    suspend fun recordSeen(device: LocalDevice) {
        val key = device.macAddress ?: device.ipAddress
        val existing = dao.getByKey(key)
        dao.upsert(
            DeviceEntity(
                macOrIp = key,
                lastIp = device.ipAddress,
                hostname = device.hostname ?: existing?.hostname,
                vendor = device.vendor ?: existing?.vendor,
                customName = existing?.customName,
                isFavorite = existing?.isFavorite ?: false,
                firstSeen = existing?.firstSeen ?: device.firstSeen,
                lastSeen = device.lastSeen
            )
        )
    }

    suspend fun rename(key: String, name: String) = dao.rename(key, name)
    suspend fun setFavorite(key: String, favorite: Boolean) = dao.setFavorite(key, favorite)
    suspend fun forget(key: String) = dao.delete(key)
}
