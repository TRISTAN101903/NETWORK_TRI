package com.tristan.network.data.network

import com.tristan.network.domain.model.LocalDevice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.net.InetAddress
import java.net.NetworkInterface

/**
 * Discovers devices on the LAN the phone is currently joined to, using two
 * standard, permission-free techniques any network-admin app on Android can
 * use:
 *  1. A ping sweep of the /24 subnet derived from the phone's own IP —
 *     exactly what happens when a router's own admin page lists clients,
 *     just initiated from this device instead.
 *  2. Reading the kernel ARP cache (/proc/net/arp) to recover MAC addresses
 *     the OS already resolved during normal communication with those hosts.
 *
 * This never sends anything beyond an ICMP-style reachability probe to each
 * host and never attempts to authenticate against, connect into, or disrupt
 * any discovered device.
 */
class LocalDeviceDiscovery {

    fun discoverFlow(timeoutMs: Int = 400): Flow<LocalDevice> = flow {
        val localIp = getLocalIPv4() ?: return@flow
        val prefix = localIp.substringBeforeLast(".")
        val now = System.currentTimeMillis()

        coroutineScope {
            val arpTable = readArpTable()
            val deferredList = (1..254).map { host ->
                async(Dispatchers.IO) {
                    val ip = "$prefix.$host"
                    try {
                        val addr = InetAddress.getByName(ip)
                        if (addr.isReachable(timeoutMs)) {
                            LocalDevice(
                                ipAddress = ip,
                                macAddress = arpTable[ip],
                                hostname = addr.canonicalHostName.takeIf { it != ip },
                                vendor = arpTable[ip]?.let { vendorFromMac(it) },
                                isOnline = true,
                                firstSeen = now,
                                lastSeen = now
                            )
                        } else null
                    } catch (_: Exception) {
                        null
                    }
                }
            }
            deferredList.forEach { deferred ->
                deferred.await()?.let { emit(it) }
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun readArpTable(): Map<String, String> {
        val map = mutableMapOf<String, String>()
        try {
            val file = File("/proc/net/arp")
            if (!file.exists()) return map
            BufferedReader(FileReader(file)).use { reader ->
                reader.readLine() // header
                reader.forEachLine { line ->
                    val parts = line.trim().split(Regex("\\s+"))
                    if (parts.size >= 4) {
                        val ip = parts[0]
                        val mac = parts[3]
                        if (mac != "00:00:00:00:00:00") {
                            map[ip] = mac
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Not readable on this OS version — MAC addresses simply won't be shown.
        }
        return map
    }

    private fun getLocalIPv4(): String? {
        return try {
            NetworkInterface.getNetworkInterfaces()?.toList()
                ?.filter { it.isUp && !it.isLoopback }
                ?.flatMap { it.inetAddresses.toList() }
                ?.firstOrNull { it is java.net.Inet4Address && !it.isLoopbackAddress }
                ?.hostAddress
        } catch (_: Exception) {
            null
        }
    }

    /** OUI-prefix vendor lookup would normally use a bundled IEEE OUI database; stub for now. */
    private fun vendorFromMac(mac: String): String? = null
}
