package com.tristan.network.ui.screens.splash

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.RocketTLogo
import com.tristan.network.ui.components.TristanCopyrightFooter
import com.tristan.network.ui.theme.CyberCyan
import kotlinx.coroutines.delay

/**
 * Splash screen: rocket-T mark, TRISTAN wordmark with an animated electric
 * streak sweeping across it, the animated cursive "Tristan" signature, and
 * the TRISTAN Business copyright line — before handing off to the app.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    var showLogo by remember { mutableFloatStateOf(0f) }
    var playSignature by remember { mutableFloatStateOf(0f) }
    val streakProgress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        showLogo = 1f
        streakProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 1200, easing = LinearEasing)
        )
        playSignature = 1f
        delay(1600)
        onFinished()
    }

    NetworkParticleBackground(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedVisibility(visible = showLogo > 0f, enter = fadeIn(tween(500))) {
                    RocketTLogo(sizeDp = 96.dp)
                }
                Box(contentAlignment = Alignment.Center) {
                    androidx.compose.animation.AnimatedVisibility(visible = showLogo > 0f, enter = fadeIn(tween(600))) {
                        Text(
                            text = "TRISTAN",
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = 40.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 6.sp
                        )
                    }
                    ElectricStreak(progress = streakProgress.value)
                }
                Text(
                    text = "N E T W O R K",
                    color = CyberCyan,
                    fontSize = 14.sp,
                    letterSpacing = 8.sp,
                    modifier = Modifier
                )
                androidx.compose.foundation.layout.Spacer(Modifier.height(28.dp))
                TristanCopyrightFooter(playSignature = playSignature > 0f)
            }
        }
    }
}

@Composable
private fun ElectricStreak(progress: Float, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.width(280.dp).height(60.dp)) {
        val y = size.height / 2f
        val x = progress * size.width
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, CyberCyan, Color.White, CyberCyan, Color.Transparent),
                startX = x - 90f,
                endX = x + 90f
            ),
            start = Offset(x - 90f, y),
            end = Offset(x + 90f, y),
            strokeWidth = 3.dp.toPx(),
            cap = androidx.compose.ui.graphics.StrokeCap.Round
        )
    }
}
