package com.tristan.network.data.local.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "tristan_settings")

enum class AppThemeMode { SYSTEM, LIGHT, DARK }

/** User-configurable settings, persisted locally only (never synced to any server). */
class SettingsDataStore(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val SCAN_INTERVAL_SEC = intPreferencesKey("scan_interval_sec")
        val AUTO_REFRESH = booleanPreferencesKey("auto_refresh")
        val SPEEDTEST_URL = stringPreferencesKey("speedtest_url")
        val PING_TARGET = stringPreferencesKey("ping_target")

        // Game Booster
        val GAME_OVERLAY_ENABLED = booleanPreferencesKey("game_overlay_enabled")
        val GAME_FPS_TARGET = intPreferencesKey("game_fps_target")
        val GAME_PERF_MODE = stringPreferencesKey("game_perf_mode")
        val GAME_AUTO_DND = booleanPreferencesKey("game_auto_dnd")
        val GAME_TRACKED_PACKAGES = stringPreferencesKey("game_tracked_packages") // comma-separated
    }

    val themeMode: Flow<AppThemeMode> = context.dataStore.data.map { prefs ->
        when (prefs[Keys.THEME_MODE]) {
            "LIGHT" -> AppThemeMode.LIGHT
            "DARK" -> AppThemeMode.DARK
            else -> AppThemeMode.SYSTEM
        }
    }

    val scanIntervalSeconds: Flow<Int> = context.dataStore.data.map { it[Keys.SCAN_INTERVAL_SEC] ?: 10 }
    val autoRefresh: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_REFRESH] ?: true }
    val pingTarget: Flow<String> = context.dataStore.data.map { it[Keys.PING_TARGET] ?: "8.8.8.8" }
    val speedTestUrl: Flow<String> = context.dataStore.data.map {
        it[Keys.SPEEDTEST_URL] ?: "https://speed.cloudflare.com/__down?bytes=25000000"
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setScanInterval(seconds: Int) {
        context.dataStore.edit { it[Keys.SCAN_INTERVAL_SEC] = seconds }
    }

    suspend fun setAutoRefresh(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_REFRESH] = enabled }
    }

    suspend fun setPingTarget(target: String) {
        context.dataStore.edit { it[Keys.PING_TARGET] = target }
    }

    // --- Game Booster ---

    val gameOverlayEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.GAME_OVERLAY_ENABLED] ?: false }
    val gameFpsTarget: Flow<Int> = context.dataStore.data.map { it[Keys.GAME_FPS_TARGET] ?: 60 }
    val gamePerfMode: Flow<String> = context.dataStore.data.map { it[Keys.GAME_PERF_MODE] ?: "BALANCED" }
    val gameAutoDnd: Flow<Boolean> = context.dataStore.data.map { it[Keys.GAME_AUTO_DND] ?: true }
    val gameTrackedPackages: Flow<Set<String>> = context.dataStore.data.map {
        (it[Keys.GAME_TRACKED_PACKAGES] ?: "").split(",").filter { pkg -> pkg.isNotBlank() }.toSet()
    }

    suspend fun setGameOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.GAME_OVERLAY_ENABLED] = enabled }
    }

    suspend fun setGameFpsTarget(fps: Int) {
        context.dataStore.edit { it[Keys.GAME_FPS_TARGET] = fps }
    }

    suspend fun setGamePerfMode(mode: String) {
        context.dataStore.edit { it[Keys.GAME_PERF_MODE] = mode }
    }

    suspend fun setGameAutoDnd(enabled: Boolean) {
        context.dataStore.edit { it[Keys.GAME_AUTO_DND] = enabled }
    }

    suspend fun addTrackedGamePackage(packageName: String) {
        context.dataStore.edit {
            val current = (it[Keys.GAME_TRACKED_PACKAGES] ?: "").split(",").filter { p -> p.isNotBlank() }.toMutableSet()
            current += packageName
            it[Keys.GAME_TRACKED_PACKAGES] = current.joinToString(",")
        }
    }

    suspend fun removeTrackedGamePackage(packageName: String) {
        context.dataStore.edit {
            val current = (it[Keys.GAME_TRACKED_PACKAGES] ?: "").split(",").filter { p -> p.isNotBlank() }.toMutableSet()
            current -= packageName
            it[Keys.GAME_TRACKED_PACKAGES] = current.joinToString(",")
        }
    }
}
