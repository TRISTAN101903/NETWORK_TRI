package com.tristan.network.data.network

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Process
import com.tristan.network.domain.model.InstalledGame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

/**
 * Detects when a game the user has opted into tracking is in the foreground,
 * using Android's standard Usage Access API (the same mechanism Digital
 * Wellbeing / any "game mode" app uses) — never an Accessibility Service,
 * which would be far more invasive for this job.
 *
 * Usage Access is a special permission the user must explicitly grant from
 * Settings (there is no runtime permission dialog for it); [hasUsageAccess]
 * / [openUsageAccessSettings] handle that flow.
 */
class GameDetector(private val context: Context) {

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettingsIntent(): android.content.Intent =
        android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)

    /**
     * All launchable user apps. Real games are flagged (Android's own "Game" category or the
     * legacy FLAG_IS_GAME) and sorted first, but EVERY app is listed because many games —
     * sideloaded ones, or ones from other stores — are not categorized as games by Android.
     * Needs the <queries> LAUNCHER entry in the manifest on Android 11+.
     */
    @Suppress("DEPRECATION")
    fun listInstalledGames(): List<InstalledGame> {
        val pm = context.packageManager
        val launcherIntent = android.content.Intent(android.content.Intent.ACTION_MAIN)
            .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(launcherIntent, 0)
        return resolved
            .asSequence()
            .mapNotNull { ri ->
                val info = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
                if (info.packageName == context.packageName) return@mapNotNull null
                val isGame = info.category == ApplicationInfo.CATEGORY_GAME ||
                    (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                InstalledGame(
                    packageName = info.packageName,
                    label = ri.loadLabel(pm)?.toString() ?: info.packageName,
                    isGame = isGame
                )
            }
            .distinctBy { it.packageName }
            .sortedWith(compareByDescending<InstalledGame> { it.isGame }.thenBy { it.label.lowercase() })
            .toList()
    }

    /**
     * Emits the package currently in the foreground (null when none / permission missing),
     * only when it changes. Instead of looking at a tiny recent window (which missed a game
     * that had already been open for a while), it replays usage events incrementally into a
     * small state machine, so the right answer is known from the very first poll.
     */
    fun foregroundPackageFlow(intervalMs: Long = 1500): Flow<String?> = flow {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        var current: String? = null
        var since = System.currentTimeMillis() - 6 * 60 * 60 * 1000L
        var lastEmitted: String? = "<unset>"
        while (true) {
            if (!hasUsageAccess()) {
                current = null
            } else {
                try {
                    val now = System.currentTimeMillis()
                    val events = usm.queryEvents(since, now)
                    val event = android.app.usage.UsageEvents.Event()
                    while (events.hasNextEvent()) {
                        events.getNextEvent(event)
                        when (event.eventType) {
                            android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED -> current = event.packageName
                            android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED ->
                                if (current == event.packageName) current = null
                            android.app.usage.UsageEvents.Event.SCREEN_NON_INTERACTIVE -> current = null
                        }
                    }
                    since = now - 1000L
                } catch (_: Exception) {
                    // Transient failure — keep the last known state and try again next tick.
                }
            }
            if (current != lastEmitted) {
                lastEmitted = current
                emit(current)
            }
            delay(intervalMs)
        }
    }.flowOn(Dispatchers.Default)
}
