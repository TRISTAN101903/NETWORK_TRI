package com.tristan.network.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tristan.network.data.network.NetworkAnalyzer
import com.tristan.network.data.network.WifiRepository
import com.tristan.network.domain.model.CurrentWifiInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DashboardUiState(
    val wifiInfo: CurrentWifiInfo? = null,
    val isCheckingInternet: Boolean = false,
    val internetReachable: Boolean? = null,
    val isRefreshing: Boolean = false
)

class DashboardViewModel(
    private val wifiRepository: WifiRepository,
    private val networkAnalyzer: NetworkAnalyzer
) : ViewModel() {

    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    init {
        refresh()
        autoRefreshLoop()
    }

    private fun autoRefreshLoop() {
        viewModelScope.launch {
            while (true) {
                delay(5000)
                refreshWifiOnly()
            }
        }
    }

    private fun refreshWifiOnly() {
        _state.value = _state.value.copy(wifiInfo = wifiRepository.getCurrentWifiInfo())
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isRefreshing = true)
            _state.value = _state.value.copy(wifiInfo = wifiRepository.getCurrentWifiInfo())
            checkInternet()
            _state.value = _state.value.copy(isRefreshing = false)
        }
    }

    fun checkInternet() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isCheckingInternet = true)
            val result = networkAnalyzer.httpCheck("https://connectivitycheck.gstatic.com/generate_204")
            _state.value = _state.value.copy(
                isCheckingInternet = false,
                internetReachable = result.success
            )
        }
    }
}
