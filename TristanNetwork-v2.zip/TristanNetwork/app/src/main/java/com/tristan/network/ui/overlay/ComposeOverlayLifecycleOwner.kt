package com.tristan.network.ui.overlay

import android.os.Bundle
import android.view.View
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner

/**
 * A ComposeView added directly via WindowManager (not inside an Activity)
 * has no LifecycleOwner / ViewModelStoreOwner / SavedStateRegistryOwner in
 * its view tree, which Compose requires to run at all. This supplies a
 * minimal standalone one, scoped to the lifetime of [GameOverlayService].
 *
 * This is the standard, well-documented pattern for hosting Jetpack Compose
 * inside a floating/overlay Service window (the same technique used by
 * system-alert-window "bubble" style widgets).
 */
class ComposeOverlayLifecycleOwner : SavedStateRegistryOwner, ViewModelStoreOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    fun performRestore(bundle: Bundle?) {
        savedStateRegistryController.performRestore(bundle)
    }

    fun handleLifecycleEvent(event: Lifecycle.Event) {
        lifecycleRegistry.handleLifecycleEvent(event)
    }

    /** Wires this owner into the given overlay root view's ViewTree*Owner slots. */
    fun attachTo(view: View) {
        view.setViewTreeLifecycleOwner(this)
        view.setViewTreeViewModelStoreOwner(this)
        view.setViewTreeSavedStateRegistryOwner(this)
    }

    fun destroy() {
        // Never moved past INITIALIZED (overlay was never shown) -> nothing to tear down;
        // sending ON_PAUSE from INITIALIZED throws IllegalStateException.
        if (lifecycleRegistry.currentState == Lifecycle.State.INITIALIZED ||
            lifecycleRegistry.currentState == Lifecycle.State.DESTROYED
        ) return
        handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}
