package com.tristan.network.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.theme.CyberCyan
import com.tristan.network.ui.theme.CyberViolet

/**
 * The "premium VIP" TRISTAN mark: a rocket whose fuselage and fins are built
 * from the letter T, finished in a cyan→violet gradient with a white nose
 * highlight and an animated thruster glow underneath. This is the app's
 * logo motif, reused on the splash screen and the About/Settings screen.
 */
@Composable
fun RocketTLogo(modifier: Modifier = Modifier, sizeDp: Dp = 120.dp, animateThruster: Boolean = true) {
    val transition = rememberInfiniteTransition(label = "thruster")
    val flicker by transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(260, easing = LinearEasing), RepeatMode.Reverse),
        label = "flicker"
    )

    Canvas(modifier = modifier.size(sizeDp)) {
        val w = size.width
        val h = size.height
        val cx = w / 2f

        // --- Thruster glow (drawn first, underneath the rocket) ---
        if (animateThruster) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CyberCyan.copy(alpha = 0.55f * flicker),
                        Color.Transparent
                    ),
                    center = Offset(cx, h * 0.92f),
                    radius = w * 0.32f
                ),
                radius = w * 0.32f,
                center = Offset(cx, h * 0.92f)
            )
        }

        // --- Fuselage: the vertical stroke of the "T", shaped like a rocket body ---
        val body = Path().apply {
            moveTo(cx, h * 0.04f) // nose tip
            cubicTo(cx + w * 0.10f, h * 0.10f, cx + w * 0.11f, h * 0.30f, cx + w * 0.085f, h * 0.60f)
            lineTo(cx + w * 0.085f, h * 0.78f)
            lineTo(cx - w * 0.085f, h * 0.78f)
            lineTo(cx - w * 0.085f, h * 0.60f)
            cubicTo(cx - w * 0.11f, h * 0.30f, cx - w * 0.10f, h * 0.10f, cx, h * 0.04f)
            close()
        }
        drawPath(
            path = body,
            brush = Brush.verticalGradient(
                listOf(Color.White, CyberCyan, CyberViolet),
                startY = 0f,
                endY = h * 0.78f
            )
        )

        // --- Crossbar / fins: the horizontal stroke of the "T", swept back like fins ---
        val fins = Path().apply {
            moveTo(cx - w * 0.085f, h * 0.52f)
            lineTo(cx - w * 0.30f, h * 0.74f)
            lineTo(cx - w * 0.085f, h * 0.68f)
            close()
            moveTo(cx + w * 0.085f, h * 0.52f)
            lineTo(cx + w * 0.30f, h * 0.74f)
            lineTo(cx + w * 0.085f, h * 0.68f)
            close()
        }
        drawPath(
            path = fins,
            brush = Brush.horizontalGradient(listOf(CyberViolet, CyberCyan))
        )

        // --- Exhaust flame ---
        val flame = Path().apply {
            moveTo(cx - w * 0.06f, h * 0.78f)
            lineTo(cx, h * (0.90f + 0.06f * (flicker - 0.55f) / 0.45f))
            lineTo(cx + w * 0.06f, h * 0.78f)
            close()
        }
        drawPath(
            path = flame,
            brush = Brush.verticalGradient(
                listOf(Color.White.copy(alpha = flicker), CyberCyan.copy(alpha = 0f)),
                startY = h * 0.78f,
                endY = h * 0.95f
            )
        )

        // --- Window ---
        drawCircle(
            color = Color.White.copy(alpha = 0.9f),
            radius = w * 0.045f,
            center = Offset(cx, h * 0.34f)
        )
        drawCircle(
            color = CyberViolet,
            radius = w * 0.028f,
            center = Offset(cx, h * 0.34f)
        )
    }
}
