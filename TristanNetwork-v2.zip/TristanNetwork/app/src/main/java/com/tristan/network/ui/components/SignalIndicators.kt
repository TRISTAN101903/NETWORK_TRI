package com.tristan.network.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tristan.network.domain.model.SignalLevel
import com.tristan.network.ui.theme.tristanColors

@Composable
fun colorForSignal(level: SignalLevel): Color {
    val colors = MaterialTheme.tristanColors
    return when (level) {
        SignalLevel.EXCELLENT -> colors.signalExcellent
        SignalLevel.GOOD -> colors.signalGood
        SignalLevel.FAIR -> colors.signalFair
        SignalLevel.POOR -> colors.signalPoor
    }
}

@Composable
fun SignalBars(level: SignalLevel, modifier: Modifier = Modifier) {
    val color = colorForSignal(level)
    val activeBars = when (level) {
        SignalLevel.EXCELLENT -> 4
        SignalLevel.GOOD -> 3
        SignalLevel.FAIR -> 2
        SignalLevel.POOR -> 1
    }
    Row(modifier = modifier, verticalAlignment = Alignment.Bottom) {
        for (i in 1..4) {
            Box(
                modifier = Modifier
                    .padding(horizontal = 1.dp)
                    .size(width = 4.dp, height = (6 + i * 3).dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(if (i <= activeBars) color else color.copy(alpha = 0.2f))
            )
        }
    }
}

@Composable
fun StatusPill(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
    }
}

@Composable
fun SecurityBadge(security: String, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.tristanColors
    val color = when {
        security.equals("Open", ignoreCase = true) -> colors.securityOpen
        security.contains("WEP", ignoreCase = true) -> colors.securityOpen
        security.contains("WPA3") -> colors.securityStrong
        security.contains("WPA2") -> colors.securityStrong
        else -> colors.securityWeak
    }
    StatusPill(text = security, color = color, modifier = modifier)
}
