package com.tristan.network.ui.screens.devices

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tristan.network.data.repository.DeviceRepository
import com.tristan.network.domain.model.LocalDevice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DevicesUiState(
    val isScanning: Boolean = false,
    val devices: List<LocalDevice> = emptyList()
)

class DevicesViewModel(private val repository: DeviceRepository) : ViewModel() {

    private val _state = MutableStateFlow(DevicesUiState())
    val state: StateFlow<DevicesUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeKnownDevices().collect { known ->
                // Merge known (offline-by-default) devices with any live discovery results already held.
                val liveMap = _state.value.devices.filter { it.isOnline }.associateBy { it.macAddress ?: it.ipAddress }
                val merged = known.map { k ->
                    val key = k.macAddress ?: k.ipAddress
                    liveMap[key]?.copy(customName = k.customName, isFavorite = k.isFavorite) ?: k
                }
                _state.value = _state.value.copy(devices = merged)
            }
        }
        scan()
    }

    fun scan() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isScanning = true)
            val found = mutableListOf<LocalDevice>()
            repository.discoverLive().collect { device ->
                repository.recordSeen(device)
                found.add(device)
                val others = _state.value.devices.filter { d -> found.none { it.ipAddress == d.ipAddress } }
                _state.value = _state.value.copy(devices = (found + others).distinctBy { it.ipAddress })
            }
            _state.value = _state.value.copy(isScanning = false)
        }
    }

    fun rename(device: LocalDevice, name: String) {
        viewModelScope.launch {
            repository.rename(device.macAddress ?: device.ipAddress, name)
        }
    }

    fun toggleFavorite(device: LocalDevice) {
        viewModelScope.launch {
            repository.setFavorite(device.macAddress ?: device.ipAddress, !device.isFavorite)
        }
    }
}
