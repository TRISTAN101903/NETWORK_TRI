package com.tristan.network.data.network

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import com.tristan.network.domain.model.BoosterResult
import com.tristan.network.domain.model.JunkScanResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * "Device & Wi-Fi speed boost" — deliberately built from only the real,
 * documented things a normal (non-root, non-system) Android app is allowed
 * to do:
 *
 *  - Ask the OS to trim cached background processes ([ActivityManager]
 *    honors or ignores this per-process at its own discretion — there is no
 *    way for a normal app to force-kill arbitrary other apps on modern
 *    Android, and this code does not pretend otherwise).
 *  - Clear THIS app's own cache directory (an app cannot clear another
 *    app's cache without the user doing it from Settings).
 *  - Best-effort Wi-Fi reconnect, with the real system Wi-Fi panel as the
 *    reliable fallback the user can act on themselves, since Android 10+
 *    does not let normal apps toggle Wi-Fi directly.
 *
 * Nothing here requires root, an accessibility service, or any permission
 * beyond what's already declared in the manifest.
 */
class BoosterRepository(private val context: Context) {

    private val activityManager: ActivityManager
        get() = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    private val wifiManager: WifiManager
        get() = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    fun memorySnapshot(): BoosterResult.MemorySnapshot {
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        val usedPercent = if (info.totalMem > 0) {
            (100.0 * (info.totalMem - info.availMem) / info.totalMem).roundToInt()
        } else 0
        return BoosterResult.MemorySnapshot(
            totalMb = info.totalMem / (1024 * 1024),
            availableMb = info.availMem / (1024 * 1024),
            usedPercent = usedPercent,
            isLowMemory = info.lowMemory
        )
    }

    /**
     * Requests that the OS trim cached/background processes belonging to
     * other, non-system launchable apps. This is a *request*: Android
     * decides per-process whether to actually honor it, and will ignore it
     * for anything it considers important (foreground, persistent, system).
     * Returns how many packages were asked and the before/after free-RAM
     * delta actually observed — not an invented number.
     */
    suspend fun trimBackgroundApps(): BoosterResult.TrimResult = withContext(Dispatchers.Default) {
        val before = memorySnapshot()
        val pm = context.packageManager
        val ownPackage = context.packageName

        // Home launcher must never be killed.
        val homePackage = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName

        // Launchable apps (visible thanks to <queries> in the manifest), excluding pure system apps.
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launchablePackages = pm.queryIntentActivities(launcherIntent, 0)
            .asSequence()
            .mapNotNull { it.activityInfo?.applicationInfo }
            .filter { it.packageName != ownPackage && it.packageName != homePackage }
            .filter {
                val isSystem = (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val updatedSystem = (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                !isSystem || updatedSystem
            }
            .map { it.packageName }
            .distinct()
            .toList()

        var requested = 0
        for (pkg in launchablePackages) {
            try {
                activityManager.killBackgroundProcesses(pkg)
                requested++
            } catch (_: SecurityException) {
                // Protected package — OS refused, which is expected and fine.
            }
        }

        // Give the OS a moment to actually reclaim memory so the measured delta is real.
        kotlinx.coroutines.delay(900)
        val after = memorySnapshot()
        BoosterResult.TrimResult(
            packagesRequested = requested,
            freedMb = (after.availableMb - before.availableMb).coerceAtLeast(0)
        )
    }

    /** Clears this app's own cache (internal + external + code cache). Returns bytes removed. */
    fun clearOwnCache(): Long {
        var total = 0L
        val dirs = buildList {
            context.cacheDir?.let { add(it) }
            context.codeCacheDir?.let { add(it) }
            context.externalCacheDirs?.filterNotNull()?.forEach { add(it) }
        }
        for (dir in dirs) {
            try {
                total += dirSize(dir)
                dir.listFiles()?.forEach { it.deleteRecursively() }
            } catch (_: Exception) {
                // Skip anything we can't touch.
            }
        }
        return total
    }

    private fun dirSize(dir: java.io.File): Long =
        dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    // ---- Real junk-file cleaning on shared storage (needs "All files access") ----

    fun hasAllFilesAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) android.os.Environment.isExternalStorageManager() else false

    fun openAllFilesAccessIntent(): Intent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
        }

    fun openAllFilesAccessFallbackIntent(): Intent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
        } else {
            Intent(Settings.ACTION_SETTINGS)
        }

    /**
     * Scans shared storage for files that are safe to delete: temp/log/incomplete-download
     * files and thumbnail caches. Never touches Android/data, Android/obb, photos, videos,
     * documents or downloads. Nothing is deleted here — the user confirms first.
     */
    suspend fun scanJunk(): JunkScanResult = withContext(Dispatchers.IO) {
        if (!hasAllFilesAccess()) return@withContext JunkScanResult(emptyList(), 0L)
        val root = android.os.Environment.getExternalStorageDirectory()
        val junkExt = setOf("tmp", "temp", "log", "crdownload", "part", "partial", "thumb")
        val found = ArrayList<java.io.File>()
        var total = 0L
        try {
            root.walkTopDown()
                .onEnter { dir -> !(dir.parentFile == root && dir.name.equals("Android", ignoreCase = true)) }
                .forEach { f ->
                    if (found.size >= 20000) return@forEach
                    if (f.isFile) {
                        val inThumbDir = f.parentFile?.name.equals(".thumbnails", ignoreCase = true)
                        val isJunk = inThumbDir ||
                            f.extension.lowercase() in junkExt ||
                            f.name.startsWith(".thumbdata", ignoreCase = true)
                        if (isJunk) {
                            found.add(f)
                            total += f.length()
                        }
                    }
                }
        } catch (_: Exception) {
            // Partial result is fine.
        }
        JunkScanResult(found, total)
    }

    /** Deletes the previously scanned junk files. Returns bytes actually freed. */
    suspend fun deleteJunk(files: List<java.io.File>): Long = withContext(Dispatchers.IO) {
        var freed = 0L
        for (f in files) {
            try {
                val size = f.length()
                if (f.delete()) freed += size
            } catch (_: Exception) {
            }
        }
        freed
    }

    /**
     * Asks the system to clear caches of ALL apps (the system shows its own confirmation).
     * Android doesn't let a normal app do this silently; this is the real, supported route.
     */
    fun clearAllAppsCacheIntent(): Intent = Intent("android.os.storage.action.CLEAR_APP_CACHE")

    fun openStorageSettingsIntent(): Intent = Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)

    /**
     * Best-effort Wi-Fi link refresh. On Android 10+, normal apps can no
     * longer force Wi-Fi to reconnect — this call is made anyway (it is a
     * harmless no-op where the OS blocks it) and the caller should treat
     * [openWifiPanelIntent] as the dependable alternative.
     */
    @Suppress("DEPRECATION")
    fun attemptWifiReconnect(): Boolean = try {
        wifiManager.reconnect()
    } catch (_: SecurityException) {
        false
    }

    fun isWifiOn(): Boolean = wifiManager.isWifiEnabled

    /** The system's own Wi-Fi quick panel — the reliable way to actually cycle Wi-Fi on modern Android. */
    fun openWifiPanelIntent(): Intent = Intent(Settings.Panel.ACTION_WIFI)

    fun openPrivateDnsSettingsIntent(): Intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)

    /** Deep-links to this app's own storage/cache page in system Settings, for other apps the user wants to clear. */
    fun openAllAppsStorageSettingsIntent(): Intent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APPLICATION_SETTINGS)
        } else {
            Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
        }

    fun openBatteryOptimizationSettingsIntent(): Intent =
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, Uri.parse("package:${context.packageName}"))
}
