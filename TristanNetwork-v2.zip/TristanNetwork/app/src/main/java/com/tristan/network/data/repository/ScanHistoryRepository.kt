package com.tristan.network.data.repository

import com.tristan.network.data.local.db.ScanHistoryDao
import com.tristan.network.data.local.db.ScanHistoryEntity
import com.tristan.network.domain.model.ScannedNetwork
import kotlinx.coroutines.flow.Flow

class ScanHistoryRepository(private val dao: ScanHistoryDao) {

    fun observeRecent(): Flow<List<ScanHistoryEntity>> = dao.observeRecent()

    suspend fun record(networks: List<ScannedNetwork>) {
        dao.insertAll(
            networks.map {
                ScanHistoryEntity(
                    ssid = it.ssid,
                    bssid = it.bssid,
                    rssiDbm = it.rssiDbm,
                    frequencyMhz = it.frequencyMhz,
                    channel = it.channel,
                    security = it.security,
                    timestamp = it.timestamp
                )
            }
        )
    }

    suspend fun pruneOlderThan(timestamp: Long) = dao.pruneOlderThan(timestamp)
}
