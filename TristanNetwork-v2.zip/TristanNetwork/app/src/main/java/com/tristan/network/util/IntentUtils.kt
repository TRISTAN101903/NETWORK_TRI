package com.tristan.network.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Starts an activity without ever crashing the app: some OEM ROMs don't ship every
 * Settings screen (Wi-Fi panel, overlay permission page, ...). Returns false and shows a
 * short toast instead of throwing.
 */
fun Context.startActivitySafely(intent: Intent, fallback: Intent? = null): Boolean {
    fun tryStart(i: Intent): Boolean = try {
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (_: ActivityNotFoundException) {
        false
    } catch (_: SecurityException) {
        false
    } catch (_: Exception) {
        false
    }

    if (tryStart(intent)) return true
    if (fallback != null && tryStart(fallback)) return true
    Toast.makeText(this, "Máy không hỗ trợ mở màn hình cài đặt này", Toast.LENGTH_SHORT).show()
    return false
}
