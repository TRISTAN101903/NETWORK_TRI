package com.tristan.network

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.tristan.network.data.local.datastore.AppThemeMode
import com.tristan.network.ui.ViewModelFactoryProvider
import com.tristan.network.ui.overlay.GameOverlayService
import kotlinx.coroutines.flow.first
import com.tristan.network.ui.navigation.TristanNavGraph
import com.tristan.network.ui.screens.splash.SplashScreen
import com.tristan.network.ui.theme.TristanNetworkTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val container = (application as TristanApplication).container

        setContent {
            ViewModelFactoryProvider(container) {
                // Bring Game Booster back automatically when the app is opened, if it was enabled
                // and all required permissions are still granted.
                LaunchedEffect(Unit) {
                    try {
                        val enabled = container.settingsDataStore.gameOverlayEnabled.first()
                        if (enabled &&
                            android.provider.Settings.canDrawOverlays(this@MainActivity) &&
                            container.gameDetector.hasUsageAccess()
                        ) {
                            androidx.core.content.ContextCompat.startForegroundService(
                                this@MainActivity,
                                android.content.Intent(this@MainActivity, GameOverlayService::class.java)
                            )
                        }
                    } catch (_: Exception) {
                        // Never crash app start over the optional overlay.
                    }
                }

                var showSplash by remember { mutableStateOf(true) }
                val themeMode by container.settingsDataStore.themeMode.collectAsState(initial = AppThemeMode.SYSTEM)
                val darkTheme = when (themeMode) {
                    AppThemeMode.SYSTEM -> isSystemInDarkTheme()
                    AppThemeMode.LIGHT -> false
                    AppThemeMode.DARK -> true
                }

                // Status/navigation bar icons must follow the APP theme (not only the system one).
                DisposableEffect(darkTheme) {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.auto(
                            android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT
                        ) { darkTheme },
                        navigationBarStyle = SystemBarStyle.auto(
                            android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT
                        ) { darkTheme }
                    )
                    onDispose { }
                }

                TristanNetworkTheme(darkTheme = darkTheme) {
                    if (showSplash) {
                        SplashScreen(onFinished = { showSplash = false })
                    } else {
                        TristanNavGraph()
                    }
                }
            }
        }
    }
}
