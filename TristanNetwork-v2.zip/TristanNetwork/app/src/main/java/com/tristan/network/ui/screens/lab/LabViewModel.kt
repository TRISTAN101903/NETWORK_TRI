package com.tristan.network.ui.screens.lab

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

data class LabDevice(val name: String, val ip: String, val signal: Int)
data class LabNetwork(val ssid: String, val security: String, val devices: List<LabDevice>)

data class LabUiState(
    val network: LabNetwork? = null,
    val isGenerating: Boolean = false,
    val evaluationLog: List<String> = emptyList()
)

/**
 * Wi-Fi Security Lab: a fully offline sandbox with synthetic, randomly
 * generated SSIDs/devices/topology. Nothing here ever touches a real radio,
 * a real network, or a real device — it exists purely so the security-audit
 * scoring logic can be exercised safely against made-up data.
 */
class LabViewModel : ViewModel() {

    private val _state = MutableStateFlow(LabUiState())
    val state: StateFlow<LabUiState> = _state.asStateFlow()

    fun generateSyntheticNetwork() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isGenerating = true, evaluationLog = emptyList())
            delay(600)
            val securities = listOf("WPA3", "WPA2", "WPA", "Open")
            val security = securities.random()
            val devices = (1..Random.nextInt(3, 9)).map { i ->
                LabDevice(
                    name = "Simulated-Device-$i",
                    ip = "10.0.0.${Random.nextInt(2, 254)}",
                    signal = Random.nextInt(-90, -40)
                )
            }
            val network = LabNetwork(
                ssid = "LAB-${Random.nextInt(1000, 9999)}",
                security = security,
                devices = devices
            )
            _state.value = _state.value.copy(network = network, isGenerating = false)
            evaluateSynthetic(network)
        }
    }

    private fun evaluateSynthetic(network: LabNetwork) {
        val log = mutableListOf<String>()
        log += "Simulated SSID: ${network.ssid}"
        log += when (network.security) {
            "WPA3" -> "✓ Encryption: WPA3 (strong)"
            "WPA2" -> "✓ Encryption: WPA2 (acceptable)"
            "WPA" -> "⚠ Encryption: WPA only — recommend upgrading"
            else -> "✗ Encryption: Open — no password protection"
        }
        log += "Simulated device count: ${network.devices.size}"
        network.devices.filter { it.signal < -80 }.forEach {
            log += "⚠ ${it.name} has a weak simulated signal (${it.signal} dBm)"
        }
        _state.value = _state.value.copy(evaluationLog = log)
    }
}
