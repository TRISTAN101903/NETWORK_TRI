package com.tristan.network.data.network

import android.content.Context
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.WifiManager.WIFI_STATE_CHANGED_ACTION
import android.os.Build
import androidx.core.content.ContextCompat
import com.tristan.network.domain.model.CurrentWifiInfo
import com.tristan.network.domain.model.ScannedNetwork
import com.tristan.network.domain.model.frequencyToChannel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.suspendCancellableCoroutine
import java.net.Inet4Address
import kotlin.coroutines.resume

/**
 * Thin, read-only wrapper around WifiManager / ConnectivityManager.
 * Every value here comes straight from Android's public APIs — nothing is
 * cracked, brute-forced, or inferred beyond what the OS already exposes to
 * any app holding the standard ACCESS_WIFI_STATE / location permission.
 */
class WifiRepository(private val context: Context) {

    private val wifiManager: WifiManager by lazy {
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    }
    private val connectivityManager: ConnectivityManager by lazy {
        context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    @Suppress("DEPRECATION")
    fun getCurrentWifiInfo(): CurrentWifiInfo {
        val wifiInfo = wifiManager.connectionInfo
        val network = connectivityManager.activeNetwork
        val caps = network?.let { connectivityManager.getNetworkCapabilities(it) }
        val linkProps: LinkProperties? = network?.let { connectivityManager.getLinkProperties(it) }

        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val isValidated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true

        val ssidRaw = wifiInfo?.ssid?.removeSurrounding("\"")
        val ssid = if (ssidRaw == WifiManager.UNKNOWN_SSID || ssidRaw.isNullOrBlank()) null else ssidRaw

        val ipAddress = linkProps?.linkAddresses
            ?.mapNotNull { it.address as? Inet4Address }
            ?.firstOrNull()?.hostAddress

        val gateway = linkProps?.routes
            ?.firstOrNull { it.isDefaultRoute }
            ?.gateway?.hostAddress

        val dnsServers = linkProps?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()

        val freq = wifiInfo?.frequency ?: -1
        val security = wifiCapabilitiesToSecurity(wifiInfo?.let { info ->
            // Current connection security isn't directly exposed pre-API33 without scan match;
            // best-effort: look up matching scan result if available.
            findSecurityForConnectedSsid(ssid)
        })

        return CurrentWifiInfo(
            ssid = ssid,
            bssid = if (isWifi) wifiInfo?.bssid?.takeIf { it != "02:00:00:00:00:00" } else null,
            rssiDbm = if (isWifi) wifiInfo?.rssi else null,
            linkSpeedMbps = if (isWifi) wifiInfo?.linkSpeed else null,
            frequencyMhz = if (isWifi && freq > 0) freq else null,
            channel = if (isWifi && freq > 0) frequencyToChannel(freq) else null,
            ipAddress = ipAddress,
            gateway = gateway,
            dnsServers = dnsServers,
            security = security,
            isConnected = isWifi,
            isInternetValidated = isValidated
        )
    }

    private fun findSecurityForConnectedSsid(ssid: String?): String? {
        if (ssid == null) return null
        return try {
            wifiManager.scanResults.firstOrNull { it.SSID == ssid }?.let { describeSecurity(it) }
        } catch (_: SecurityException) {
            null
        }
    }

    /** Triggers a scan and returns results once available (or immediately if throttled by OS). */
    fun scanResultsFlow(): Flow<List<ScannedNetwork>> = callbackFlow {
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: android.content.Intent?) {
                trySend(readScanResults())
            }
        }
        ContextCompat.registerReceiver(
            context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
        )
        // Emit whatever is cached immediately, then kick off a fresh scan, and keep
        // re-scanning every 25s (Android throttles foreground apps to ~4 scans / 2 min).
        trySend(readScanResults())
        launch {
            while (isActive) {
                requestScan()
                delay(25_000)
            }
        }
        awaitClose {
            try {
                context.unregisterReceiver(receiver)
            } catch (_: IllegalArgumentException) {
                // already unregistered
            }
        }
    }

    /** Asks the OS for a fresh scan. Never throws: missing permission / throttling just returns false. */
    @Suppress("DEPRECATION")
    fun requestScan(): Boolean = try {
        wifiManager.startScan()
    } catch (_: SecurityException) {
        false
    } catch (_: Exception) {
        false
    }

    /** Wi-Fi scan results are empty on most phones while system Location is switched off. */
    fun isLocationEnabled(): Boolean = try {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        lm.isLocationEnabled
    } catch (_: Exception) {
        true
    }

    fun readScanResults(): List<ScannedNetwork> {
        val results: List<ScanResult> = try {
            wifiManager.scanResults
        } catch (_: SecurityException) {
            emptyList()
        }
        val now = System.currentTimeMillis()
        return results.map { r ->
            ScannedNetwork(
                ssid = r.SSID.ifBlank { "(hidden network)" },
                bssid = r.BSSID ?: "",
                rssiDbm = r.level,
                frequencyMhz = r.frequency,
                channel = frequencyToChannel(r.frequency),
                security = describeSecurity(r),
                timestamp = now
            )
        }.distinctBy { it.bssid }
    }

    private fun describeSecurity(result: ScanResult): String {
        val caps = result.capabilities ?: ""
        return when {
            caps.contains("WPA3") -> "WPA3"
            caps.contains("WPA2") && caps.contains("WPA") -> "WPA/WPA2"
            caps.contains("WPA2") -> "WPA2"
            caps.contains("WPA") -> "WPA"
            caps.contains("WEP") -> "WEP"
            caps.contains("ESS") && !caps.contains("WPA") && !caps.contains("WEP") -> "Open"
            else -> "Unknown"
        }
    }

    private fun wifiCapabilitiesToSecurity(sec: String?) = sec

    fun isWifiEnabled(): Boolean = wifiManager.isWifiEnabled
}
