package com.tristan.network.data.local.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A single Wi-Fi scan snapshot, stored locally for history/trend views. */
@Entity(tableName = "scan_history")
data class ScanHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val frequencyMhz: Int,
    val channel: Int,
    val security: String,
    val timestamp: Long
)
