package com.tristan.network.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.R
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.data.local.datastore.AppThemeMode
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.NeonGlassCard
import com.tristan.network.ui.components.RocketTLogo
import com.tristan.network.ui.components.TristanCopyrightFooter

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val theme by viewModel.themeMode.collectAsState()
    val autoRefresh by viewModel.autoRefresh.collectAsState()
    val pingTarget by viewModel.pingTarget.collectAsState()

    NetworkParticleBackground {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("Settings", style = MaterialTheme.typography.displayLarge) }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Appearance", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AppThemeMode.values().forEach { mode ->
                                FilterChip(
                                    selected = theme == mode,
                                    onClick = { viewModel.setThemeMode(mode) },
                                    label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Auto-refresh dashboard", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Periodically re-read Wi-Fi info while viewing the dashboard",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = autoRefresh, onCheckedChange = viewModel::setAutoRefresh)
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Default ping target", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = pingTarget,
                            onValueChange = viewModel::setPingTarget,
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            }

            item {
                GlassCard {
                    Text(
                        stringResource(R.string.privacy_notice),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                NeonGlassCard {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RocketTLogo(sizeDp = 72.dp)
                        Text(
                            "Tristan Network — Premium",
                            style = MaterialTheme.typography.titleMedium
                        )
                        TristanCopyrightFooter(showSignature = true, playSignature = true)
                    }
                }
            }
        }
    }
}

@Composable
private fun stringResource(id: Int) = androidx.compose.ui.res.stringResource(id)
