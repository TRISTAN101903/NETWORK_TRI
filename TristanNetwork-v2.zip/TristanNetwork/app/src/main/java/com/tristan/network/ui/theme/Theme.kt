package com.tristan.network.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Extra tokens Material3's ColorScheme doesn't carry, used by the Liquid Glass components. */
data class TristanExtendedColors(
    val backgroundGradient: Brush,
    val glassTint: Color,
    val glassBorder: Color,
    val signalExcellent: Color,
    val signalGood: Color,
    val signalFair: Color,
    val signalPoor: Color,
    val securityOpen: Color,
    val securityWeak: Color,
    val securityStrong: Color,
    val isDark: Boolean
)

private val LocalTristanColors = staticCompositionLocalOf {
    TristanExtendedColors(
        backgroundGradient = Brush.verticalGradient(listOf(SpaceBlack, SpaceDeep)),
        glassTint = GlassTintDark,
        glassBorder = GlassBorderDark,
        signalExcellent = SignalExcellent,
        signalGood = SignalGood,
        signalFair = SignalFair,
        signalPoor = SignalPoor,
        securityOpen = SecurityOpen,
        securityWeak = SecurityWeak,
        securityStrong = SecurityStrong,
        isDark = true
    )
}

val MaterialTheme.tristanColors: TristanExtendedColors
    @Composable get() = LocalTristanColors.current

private val DarkScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = SpaceBlack,
    secondary = CyberBlue,
    onSecondary = Color.White,
    tertiary = CyberViolet,
    background = SpaceBlack,
    onBackground = OnDarkPrimary,
    surface = SpaceSurface,
    onSurface = OnDarkPrimary,
    surfaceVariant = GlassTintDark,
    onSurfaceVariant = OnDarkSecondary,
    error = SecurityOpen
)

private val LightScheme = lightColorScheme(
    primary = CyberBlue,
    onPrimary = Color.White,
    secondary = CyberCyanDeep,
    onSecondary = Color.White,
    tertiary = CyberViolet,
    background = MistWhite,
    onBackground = OnLightPrimary,
    surface = Color.White,
    onSurface = OnLightPrimary,
    surfaceVariant = MistSurface,
    onSurfaceVariant = OnLightSecondary,
    error = SecurityOpen
)

@Composable
fun TristanNetworkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val scheme = if (darkTheme) DarkScheme else LightScheme

    val extended = if (darkTheme) {
        TristanExtendedColors(
            backgroundGradient = Brush.verticalGradient(
                listOf(SpaceBlack, SpaceDeep, Color(0xFF0C1830))
            ),
            glassTint = GlassTintDark,
            glassBorder = GlassBorderDark,
            signalExcellent = SignalExcellent,
            signalGood = SignalGood,
            signalFair = SignalFair,
            signalPoor = SignalPoor,
            securityOpen = SecurityOpen,
            securityWeak = SecurityWeak,
            securityStrong = SecurityStrong,
            isDark = true
        )
    } else {
        TristanExtendedColors(
            backgroundGradient = Brush.verticalGradient(
                listOf(MistWhite, MistSurface, Color(0xFFDCEEFB))
            ),
            glassTint = GlassTintLight,
            glassBorder = GlassBorderLight,
            signalExcellent = SignalExcellent,
            signalGood = CyberBlue,
            signalFair = Color(0xFFCC8A00),
            signalPoor = SignalPoor,
            securityOpen = SecurityOpen,
            securityWeak = Color(0xFFCC8A00),
            securityStrong = Color(0xFF189A68),
            isDark = false
        )
    }

    androidx.compose.runtime.CompositionLocalProvider(LocalTristanColors provides extended) {
        MaterialTheme(
            colorScheme = scheme,
            typography = TristanTypography
        ) {
            // Root cause of "black text on dark theme": the app's Scaffolds are transparent, so
            // nothing set a content colour and every Text() without an explicit colour fell back
            // to Color.Black. Provide it here: white on dark, black on light.
            androidx.compose.runtime.CompositionLocalProvider(
                LocalContentColor provides scheme.onBackground,
                content = content
            )
        }
    }
}
