package com.tristan.network.ui.screens.audit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.RadarScanAnimation
import com.tristan.network.ui.theme.tristanColors

@Composable
fun AuditScreen(viewModel: AuditViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val state by viewModel.state.collectAsState()
    val colors = MaterialTheme.tristanColors

    LaunchedEffect(Unit) { viewModel.runAudit() }

    NetworkParticleBackground {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Text("Security Audit", style = MaterialTheme.typography.displayLarge) }

            if (state.isRunning) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RadarScanAnimation()
                        Spacer(Modifier.height(12.dp))
                        Text("Analyzing security posture…")
                    }
                }
            } else {
                item {
                    GlassCard {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Box(contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(
                                    progress = { state.score / 100f },
                                    modifier = Modifier.size(100.dp),
                                    strokeWidth = 8.dp,
                                    color = scoreColor(state.score, colors),
                                    trackColor = colors.glassBorder
                                )
                                Text("${state.score}", style = MaterialTheme.typography.displayLarge)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                scoreLabel(state.score),
                                style = MaterialTheme.typography.titleMedium,
                                color = scoreColor(state.score, colors)
                            )
                        }
                    }
                }

                items(state.findings) { finding ->
                    GlassCard {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                if (finding.passed) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                                contentDescription = null,
                                tint = if (finding.passed) colors.securityStrong else colors.signalFair,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(Modifier.height(0.dp).then(Modifier))
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(finding.title, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    finding.detail,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                finding.recommendation?.let {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        "→ $it",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = colors.signalGood
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Button(onClick = viewModel::runAudit, modifier = Modifier.fillMaxWidth()) {
                        Text("Re-run Audit")
                    }
                }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }
}

@Composable
private fun scoreColor(score: Int, colors: com.tristan.network.ui.theme.TristanExtendedColors) = when {
    score >= 80 -> colors.securityStrong
    score >= 50 -> colors.signalFair
    else -> colors.securityOpen
}

private fun scoreLabel(score: Int) = when {
    score >= 80 -> "Strong"
    score >= 50 -> "Needs attention"
    else -> "At risk"
}
