package com.tristan.network.ui.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.BatteryManager
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import com.tristan.network.MainActivity
import com.tristan.network.R
import com.tristan.network.TristanApplication
import com.tristan.network.data.local.datastore.SettingsDataStore
import com.tristan.network.data.network.GameDetector
import com.tristan.network.data.network.NetworkAnalyzer
import com.tristan.network.data.network.WifiRepository
import com.tristan.network.ui.theme.TristanNetworkTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

/**
 * Foreground service that owns the left-edge pull-out overlay. It:
 *  1. Watches for a tracked game coming to the foreground (GameDetector,
 *     via the standard Usage Access API) and shows/hides the overlay handle.
 *  2. Hosts a Jetpack Compose window (OverlayRoot) added via WindowManager,
 *     with its own minimal Lifecycle/ViewModelStore/SavedStateRegistry
 *     (ComposeOverlayLifecycleOwner) since there is no Activity here.
 *  3. Applies the real, documented things this app is actually allowed to
 *     do on behalf of "game optimization": request a preferred display
 *     refresh rate for its own overlay window, and toggle system Do Not
 *     Disturb (with the user's explicit ACCESS_NOTIFICATION_POLICY grant).
 *     It does NOT and never will attempt to hide itself from, or otherwise
 *     evade, a game's anti-cheat system.
 */
class GameOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: ComposeView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var overlayLifecycleOwner = ComposeOverlayLifecycleOwner()

    private var serviceJob: Job? = null
    private lateinit var scope: CoroutineScope

    private lateinit var gameDetector: GameDetector
    private lateinit var settings: SettingsDataStore
    private lateinit var wifiRepository: WifiRepository
    private lateinit var networkAnalyzer: NetworkAnalyzer

    private var isHandleShown = false
    private var dndAppliedByUs = false

    // Compose-observable overlay state, mutated from the service's coroutines.
    private var expanded by mutableStateOf(false)
    private var stats by mutableStateOf(
        OverlayLiveStats(ssid = null, rssiDbm = null, linkSpeedMbps = null, pingMs = null, batteryPercent = 0, isCharging = false)
    )
    private var fpsTargetState by mutableStateOf(60)
    private var perfModeState by mutableStateOf("BALANCED")
    private var autoDndState by mutableStateOf(true)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val container = (application as TristanApplication).container
        gameDetector = container.gameDetector
        settings = container.settingsDataStore
        wifiRepository = container.wifiRepository
        networkAnalyzer = container.networkAnalyzer

        startForegroundNotification()
        watchTrackedGames()
        watchPreferences()
    }

    private fun startForegroundNotification() {
        val channelId = "tristan_game_booster"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Game Booster", NotificationManager.IMPORTANCE_MIN
            ).apply { description = "Hiển thị khi overlay Game Booster đang hoạt động" }
            nm.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Tristan Network — Game Booster")
            .setContentText("Overlay đang sẵn sàng cho game của bạn")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(openAppIntent)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()

        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                0
            }
        )
    }

    private fun watchPreferences() {
        scope.launch {
            settings.gameFpsTarget.collect { fpsTargetState = it; applyPreferredRefreshRate(it) }
        }
        scope.launch {
            settings.gamePerfMode.collect { perfModeState = it }
        }
        scope.launch {
            settings.gameAutoDnd.collect { autoDndState = it }
        }
    }

    /** Combines "overlay enabled", "which games are tracked" and "what's in the foreground" into show/hide. */
    private fun watchTrackedGames() {
        serviceJob = scope.launch {
            combine(
                settings.gameOverlayEnabled,
                settings.gameTrackedPackages,
                gameDetector.foregroundPackageFlow()
            ) { enabled, tracked, foreground -> Triple(enabled, tracked, foreground) }
                .catch { /* Usage access missing or revoked mid-session — just stop showing the overlay. */ }
                .collect { (enabled, tracked, foreground) ->
                    val shouldShow = enabled && foreground != null && tracked.contains(foreground)
                    if (shouldShow && !isHandleShown) {
                        showOverlay()
                        startLiveStatsLoop()
                    } else if (!shouldShow && isHandleShown) {
                        hideOverlay()
                    }
                    applyAutoDnd(shouldShow)
                }
        }
    }

    private var statsJob: Job? = null
    private fun startLiveStatsLoop() {
        statsJob?.cancel()
        statsJob = scope.launch {
            while (true) {
                try {
                    refreshStats()
                } catch (_: Exception) {
                    // A single failed reading (e.g. transient permission/network hiccup) should
                    // never kill the overlay's refresh loop — just try again next tick.
                }
                val intervalMs = when (perfModeState) {
                    "PERFORMANCE" -> 1500L
                    "ULTRA_SAVER" -> 8000L
                    else -> 3000L
                }
                delay(intervalMs)
            }
        }
    }

    private suspend fun refreshStats() {
        val info = wifiRepository.getCurrentWifiInfo()
        val ping = if (perfModeState != "ULTRA_SAVER") {
            info.gateway?.let { gw ->
                networkAnalyzer.pingStream(gw, count = 1, timeoutMs = 800).firstOrNull()?.timeMs
            }
        } else null

        val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        stats = OverlayLiveStats(
            ssid = info.ssid,
            rssiDbm = info.rssiDbm,
            linkSpeedMbps = info.linkSpeedMbps,
            pingMs = ping,
            batteryPercent = percent,
            isCharging = charging
        )
    }

    private fun applyAutoDnd(gameActive: Boolean) {
        if (!autoDndState) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return
        try {
            if (gameActive && !dndAppliedByUs) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                dndAppliedByUs = true
            } else if (!gameActive && dndAppliedByUs) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                dndAppliedByUs = false
            }
        } catch (_: SecurityException) {
            // Policy access revoked between the check and the call — ignore, nothing to recover.
        }
    }

    /**
     * Requests a preferred display refresh rate for THIS overlay window only.
     * On many devices the compositor treats the frontmost window's preference
     * as a hint for the whole screen while that window is visible, but this
     * is a best-effort hint, not a guarantee — Android gives no normal app
     * the ability to force another app's internal render/FPS loop without
     * root.
     */
    private fun applyPreferredRefreshRate(fps: Int) {
        val params = layoutParams ?: return
        val view = overlayView ?: return
        try {
            @Suppress("DEPRECATION")
            val display = windowManager.defaultDisplay
            val mode = display.supportedModes.minByOrNull { kotlin.math.abs(it.refreshRate - fps) }
            if (mode != null) {
                params.preferredDisplayModeId = mode.modeId
                windowManager.updateViewLayout(view, params)
            }
        } catch (_: Exception) {
            // Best-effort only — never crash the overlay over a refresh-rate hint.
        }
    }

    private fun showOverlay() {
        if (overlayView != null) return
        isHandleShown = true

        // A fresh owner every time: SavedStateRegistry.performRestore() may only run once per
        // owner, so reusing one made the SECOND time a game opened crash the service.
        overlayLifecycleOwner = ComposeOverlayLifecycleOwner()
        overlayLifecycleOwner.performRestore(null)
        overlayLifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        overlayLifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_START)
        overlayLifecycleOwner.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 400
        }
        layoutParams = params

        val view = ComposeView(this).apply {
            setContent {
                TristanNetworkTheme {
                    OverlayRoot(
                        expanded = expanded,
                        onToggleExpanded = { expanded = !expanded },
                        onDrag = { dy ->
                            params.y = (params.y + dy.toInt()).coerceAtLeast(0)
                            windowManager.updateViewLayout(this@apply, params)
                        },
                        stats = stats,
                        fpsTarget = fpsTargetState,
                        onFpsSelected = { fps -> scope.launch { settings.setGameFpsTarget(fps) } },
                        perfMode = perfModeState,
                        onPerfModeSelected = { mode -> scope.launch { settings.setGamePerfMode(mode) } },
                        autoDnd = autoDndState,
                        onAutoDndToggled = { on -> scope.launch { settings.setGameAutoDnd(on) } },
                        onClose = { expanded = false },
                        onExit = {
                            // Turn Game Booster off completely and stop this service.
                            scope.launch { settings.setGameOverlayEnabled(false) }
                            stopSelf()
                        }
                    )
                }
            }
        }
        overlayLifecycleOwner.attachTo(view)
        overlayView = view

        try {
            windowManager.addView(view, params)
            applyPreferredRefreshRate(fpsTargetState)
        } catch (_: Exception) {
            // Overlay permission missing/revoked — nothing more we can do until the user grants it.
            overlayView = null
            isHandleShown = false
            overlayLifecycleOwner.destroy()
        }
    }

    private fun hideOverlay() {
        isHandleShown = false
        expanded = false
        statsJob?.cancel()
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) { /* already removed */ }
        }
        val hadView = overlayView != null
        overlayView = null
        if (hadView) overlayLifecycleOwner.destroy()
    }

    override fun onDestroy() {
        hideOverlay()
        applyAutoDnd(false)
        serviceJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 7421

        fun canStart(context: android.content.Context): Boolean =
            Settings.canDrawOverlays(context)
    }
}
