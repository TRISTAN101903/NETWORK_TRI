package com.tristan.network.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tristan.network.data.local.datastore.AppThemeMode
import com.tristan.network.data.local.datastore.SettingsDataStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val settings: SettingsDataStore) : ViewModel() {

    val themeMode: StateFlow<AppThemeMode> = settings.themeMode
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppThemeMode.SYSTEM)

    val autoRefresh: StateFlow<Boolean> = settings.autoRefresh
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    val pingTarget: StateFlow<String> = settings.pingTarget
        .stateIn(viewModelScope, SharingStarted.Eagerly, "8.8.8.8")

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch { settings.setThemeMode(mode) }
    }

    fun setAutoRefresh(enabled: Boolean) {
        viewModelScope.launch { settings.setAutoRefresh(enabled) }
    }

    fun setPingTarget(target: String) {
        viewModelScope.launch { settings.setPingTarget(target) }
    }
}
