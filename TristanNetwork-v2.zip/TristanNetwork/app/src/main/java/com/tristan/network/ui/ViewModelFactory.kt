package com.tristan.network.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.tristan.network.AppContainer
import com.tristan.network.ui.screens.analyzer.AnalyzerViewModel
import com.tristan.network.ui.screens.audit.AuditViewModel
import com.tristan.network.ui.screens.booster.BoosterViewModel
import com.tristan.network.ui.screens.dashboard.DashboardViewModel
import com.tristan.network.ui.screens.devices.DevicesViewModel
import com.tristan.network.ui.screens.gameboost.GameBoostViewModel
import com.tristan.network.ui.screens.lab.LabViewModel
import com.tristan.network.ui.screens.router.RouterViewModel
import com.tristan.network.ui.screens.scanner.ScannerViewModel
import com.tristan.network.ui.screens.settings.SettingsViewModel

/** Single manual ViewModelProvider.Factory, since this app skips Hilt/Dagger. */
class TristanViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
        return when (modelClass) {
            DashboardViewModel::class.java ->
                DashboardViewModel(container.wifiRepository, container.networkAnalyzer) as T
            ScannerViewModel::class.java ->
                ScannerViewModel(container.wifiRepository, container.scanHistoryRepository) as T
            AnalyzerViewModel::class.java ->
                AnalyzerViewModel(container.networkAnalyzer, container.settingsDataStore) as T
            DevicesViewModel::class.java ->
                DevicesViewModel(container.deviceRepository) as T
            AuditViewModel::class.java ->
                AuditViewModel(container.wifiRepository) as T
            RouterViewModel::class.java ->
                RouterViewModel() as T
            LabViewModel::class.java ->
                LabViewModel() as T
            SettingsViewModel::class.java ->
                SettingsViewModel(container.settingsDataStore) as T
            BoosterViewModel::class.java ->
                BoosterViewModel(container.boosterRepository) as T
            GameBoostViewModel::class.java ->
                GameBoostViewModel(container.gameDetector, container.settingsDataStore) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
