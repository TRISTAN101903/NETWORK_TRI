package com.tristan.network.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.theme.tristanColors

/**
 * Standard "© TRISTAN Business" copyright footer, with the animated cursive
 * signature above it. Used on the splash screen, the Settings/About screen,
 * and the in-game overlay panel so the premium branding is consistent
 * everywhere the user sees it.
 */
@Composable
fun TristanCopyrightFooter(
    modifier: Modifier = Modifier,
    showSignature: Boolean = true,
    playSignature: Boolean = true
) {
    val colors = MaterialTheme.tristanColors
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (showSignature) {
            TristanSignature(color = colors.signalGood, play = playSignature)
            Spacer(Modifier.height(4.dp))
        }
        Text(
            text = "© TRISTAN Business — Bản quyền thuộc TRISTAN",
            style = MaterialTheme.typography.labelSmall,
            color = colors.signalGood.copy(alpha = 0.75f),
            textAlign = TextAlign.Center
        )
        Text(
            text = "Tristan Network · Premium Edition",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}
