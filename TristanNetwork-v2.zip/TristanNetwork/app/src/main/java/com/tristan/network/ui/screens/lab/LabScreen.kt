package com.tristan.network.ui.screens.lab

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.RadarScanAnimation
import com.tristan.network.ui.components.SecurityBadge

@Composable
fun LabScreen(viewModel: LabViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val state by viewModel.state.collectAsState()

    NetworkParticleBackground {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("Wi-Fi Security Lab", style = MaterialTheme.typography.displayLarge) }
            item {
                Text(
                    "An offline sandbox with fully synthetic, randomly generated data — nothing here touches a real network.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                Button(onClick = viewModel::generateSyntheticNetwork, modifier = Modifier.fillMaxWidth()) {
                    Text("Generate Simulated Network")
                }
            }

            if (state.isGenerating) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RadarScanAnimation(sizeDp = 100.dp)
                    }
                }
            }

            state.network?.let { net ->
                item {
                    GlassCard {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(net.ssid, style = MaterialTheme.typography.titleMedium)
                                SecurityBadge(net.security)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("${net.devices.size} simulated devices", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                items(net.devices) { device ->
                    GlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(device.name)
                            Text("${device.ip} · ${device.signal} dBm", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            if (state.evaluationLog.isNotEmpty()) {
                item {
                    GlassCard {
                        Column {
                            Text("Evaluation", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            state.evaluationLog.forEach { line ->
                                Text(line, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}
