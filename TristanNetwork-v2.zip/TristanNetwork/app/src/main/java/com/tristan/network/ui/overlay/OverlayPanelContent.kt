package com.tristan.network.ui.overlay

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NetworkWifi
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.components.NeonGlassCard
import com.tristan.network.ui.components.SignalPulseDot
import com.tristan.network.ui.components.TristanCopyrightFooter
import com.tristan.network.ui.theme.CyberCyan
import com.tristan.network.ui.theme.tristanColors

/** Live readout shown on the overlay panel, refreshed periodically by GameOverlayService. */
data class OverlayLiveStats(
    val ssid: String?,
    val rssiDbm: Int?,
    val linkSpeedMbps: Int?,
    val pingMs: Double?,
    val batteryPercent: Int,
    val isCharging: Boolean
)

/**
 * Root content of the in-game overlay window: a slim draggable handle on the
 * left edge that expands into the "siêu công nghệ" glass control panel.
 * All drag/expand state is owned by the caller (GameOverlayService) via the
 * parameters here, since the composable itself has no Activity-scoped
 * ViewModel to hold it in.
 */
@Composable
fun OverlayRoot(
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onDrag: (dyPx: Float) -> Unit,
    stats: OverlayLiveStats,
    fpsTarget: Int,
    onFpsSelected: (Int) -> Unit,
    perfMode: String,
    onPerfModeSelected: (String) -> Unit,
    autoDnd: Boolean,
    onAutoDndToggled: (Boolean) -> Unit,
    onClose: () -> Unit,
    onExit: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        OverlayHandle(expanded = expanded, onToggleExpanded = onToggleExpanded, onDrag = onDrag)

        AnimatedVisibility(
            visible = expanded,
            enter = expandHorizontally(),
            exit = shrinkHorizontally()
        ) {
            OverlayPanel(
                stats = stats,
                fpsTarget = fpsTarget,
                onFpsSelected = onFpsSelected,
                perfMode = perfMode,
                onPerfModeSelected = onPerfModeSelected,
                autoDnd = autoDnd,
                onAutoDndToggled = onAutoDndToggled,
                onClose = onClose,
                onExit = onExit
            )
        }
    }
}

@Composable
private fun OverlayHandle(expanded: Boolean, onToggleExpanded: () -> Unit, onDrag: (Float) -> Unit) {
    val colors = MaterialTheme.tristanColors
    Box(
        modifier = Modifier
            .width(22.dp)
            .height(72.dp)
            .clip(RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp))
            .background(colors.glassTint.copy(alpha = 0.85f))
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.y)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { onToggleExpanded() }
            },
        contentAlignment = Alignment.Center
    ) {
        SignalPulseDot(modifier = Modifier.size(10.dp), color = CyberCyan)
    }
}

@Composable
private fun OverlayPanel(
    stats: OverlayLiveStats,
    fpsTarget: Int,
    onFpsSelected: (Int) -> Unit,
    perfMode: String,
    onPerfModeSelected: (String) -> Unit,
    autoDnd: Boolean,
    onAutoDndToggled: (Boolean) -> Unit,
    onClose: () -> Unit,
    onExit: () -> Unit
) {
    val colors = MaterialTheme.tristanColors
    NeonGlassCard(modifier = Modifier.widthIn(max = 280.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("TRISTAN", style = MaterialTheme.typography.titleMedium, color = CyberCyan)
                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = "Đóng",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.NetworkWifi, contentDescription = null, tint = colors.signalGood, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    stats.ssid ?: "Không kết nối Wi-Fi",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Speed, contentDescription = null, tint = colors.signalGood, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    buildString {
                        append(stats.rssiDbm?.let { "$it dBm" } ?: "—")
                        append(" · ")
                        append(stats.linkSpeedMbps?.let { "${it}Mbps" } ?: "—")
                        append(" · ping ")
                        append(stats.pingMs?.let { "${it.toInt()}ms" } ?: "—")
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.BatteryFull, contentDescription = null, tint = colors.signalGood, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "${stats.batteryPercent}%" + if (stats.isCharging) " (đang sạc)" else "",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Text("FPS", style = MaterialTheme.typography.labelLarge, color = colors.signalGood)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(30, 60, 90).forEach { fps ->
                    FilterChip(
                        selected = fpsTarget == fps,
                        onClick = { onFpsSelected(fps) },
                        label = { Text("$fps") }
                    )
                }
            }

            Text("Chế độ pin", style = MaterialTheme.typography.labelLarge, color = colors.signalGood)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("BALANCED" to "Cân bằng", "PERFORMANCE" to "Hiệu năng", "ULTRA_SAVER" to "Siêu tiết kiệm")
                    .forEach { (value, label) ->
                        FilterChip(
                            selected = perfMode == value,
                            onClick = { onPerfModeSelected(value) },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Không làm phiền", style = MaterialTheme.typography.bodyMedium)
                Switch(checked = autoDnd, onCheckedChange = onAutoDndToggled)
            }

            OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Thoát Game Booster")
            }

            TristanCopyrightFooter(showSignature = false, playSignature = false)
        }
    }
}
