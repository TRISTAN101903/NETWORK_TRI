package com.tristan.network.ui.screens.router

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.theme.tristanColors

@Composable
fun RouterScreen(viewModel: RouterViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val state by viewModel.state.collectAsState()
    val colors = MaterialTheme.tristanColors

    NetworkParticleBackground {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("Router Management", style = MaterialTheme.typography.displayLarge) }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "Enter your own router's admin address and credentials. Nothing is sent anywhere except directly to that address, once, when you tap Connect.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = state.routerAddress,
                            onValueChange = viewModel::setAddress,
                            label = { Text("Router address") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = state.username,
                            onValueChange = viewModel::setUsername,
                            label = { Text("Admin username") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = state.password,
                            onValueChange = viewModel::setPassword,
                            label = { Text("Admin password") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                        Button(
                            onClick = { if (state.connected) viewModel.disconnect() else viewModel.connect() },
                            enabled = !state.isConnecting,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                when {
                                    state.isConnecting -> "Connecting…"
                                    state.connected -> "Disconnect"
                                    else -> "Connect"
                                }
                            )
                        }
                        state.statusMessage?.let {
                            Text(it, color = if (state.connected) colors.securityStrong else colors.securityOpen)
                        }
                    }
                }
            }

            if (state.connected) {
                item {
                    GlassCard {
                        Column {
                            Text("Connected", style = MaterialTheme.typography.titleMedium, color = colors.securityStrong)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Full client-list and settings management depends on your router vendor's admin API, which varies by model. Basic connectivity is confirmed above.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}
