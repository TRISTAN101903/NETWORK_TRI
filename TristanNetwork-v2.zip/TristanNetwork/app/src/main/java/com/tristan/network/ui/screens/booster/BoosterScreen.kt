package com.tristan.network.ui.screens.booster

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tristan.network.data.network.BoosterRepository
import com.tristan.network.ui.LocalTristanViewModelFactory
import com.tristan.network.ui.components.GlassCard
import com.tristan.network.ui.components.NetworkParticleBackground
import com.tristan.network.ui.components.RocketTLogo
import com.tristan.network.ui.theme.tristanColors
import com.tristan.network.util.startActivitySafely

@Composable
fun BoosterScreen(viewModel: BoosterViewModel = viewModel(factory = LocalTristanViewModelFactory.current)) {
    val state by viewModel.state.collectAsState()
    val colors = MaterialTheme.tristanColors
    val context = LocalContext.current
    val repository = remember(context) { BoosterRepository(context) }

    // Re-check "All files access" when coming back from the system Settings page.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refreshMemory()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    NetworkParticleBackground {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Text("Tăng tốc máy & Wi-Fi", style = MaterialTheme.typography.displayLarge) }

            item {
                GlassCard {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RocketTLogo(sizeDp = 72.dp, animateThruster = state.isBoosting)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = viewModel::runFullBoost,
                            enabled = !state.isBoosting,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            androidx.compose.material3.Icon(Icons.Filled.RocketLaunch, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (state.isBoosting) "Đang tối ưu..." else "TĂNG TỐC NGAY")
                        }
                        state.statusMessage?.let {
                            Spacer(Modifier.height(8.dp))
                            Text(it, style = MaterialTheme.typography.bodyMedium, color = colors.signalGood)
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.Icon(Icons.Filled.Memory, contentDescription = null, tint = colors.signalGood)
                            Spacer(Modifier.width(8.dp))
                            Text("Bộ nhớ RAM", style = MaterialTheme.typography.titleMedium)
                        }
                        val mem = state.memory
                        if (mem != null) {
                            LinearProgressIndicator(
                                progress = { mem.usedPercent / 100f },
                                modifier = Modifier.fillMaxWidth().height(8.dp),
                                color = if (mem.isLowMemory) colors.signalPoor else colors.signalGood,
                                trackColor = colors.glassBorder
                            )
                            Text(
                                "${mem.usedPercent}% đang dùng · còn trống ${mem.availableMb}MB / ${mem.totalMb}MB",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(onClick = viewModel::trimRamOnly, modifier = Modifier.fillMaxWidth()) {
                            Text("Dọn ứng dụng chạy nền")
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.Icon(Icons.Filled.CleaningServices, contentDescription = null, tint = colors.signalGood)
                            Spacer(Modifier.width(8.dp))
                            Text("Bộ nhớ đệm", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "Xoá thật cache của Tristan. Cache của ứng dụng khác do Android quản lý: nút " +
                                "\"Dọn cache mọi ứng dụng\" sẽ mở hộp thoại hệ thống để bạn xác nhận.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = viewModel::clearCacheOnly, modifier = Modifier.weight(1f)) {
                                Text("Dọn cache Tristan")
                            }
                            OutlinedButton(
                                onClick = {
                                    context.startActivitySafely(
                                        repository.clearAllAppsCacheIntent(),
                                        fallback = repository.openStorageSettingsIntent()
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Dọn cache mọi ứng dụng")
                            }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.Icon(Icons.Filled.DeleteSweep, contentDescription = null, tint = colors.signalGood)
                            Spacer(Modifier.width(8.dp))
                            Text("Dọn file rác trong máy", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "Quét file tạm (.tmp, .log), tải dở (.crdownload, .part) và ảnh thu nhỏ cache trên bộ nhớ máy. " +
                                "Không đụng tới ảnh, video, tài liệu hay thư mục Download.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (!state.hasAllFilesAccess) {
                            Button(
                                onClick = {
                                    context.startActivitySafely(
                                        repository.openAllFilesAccessIntent(),
                                        fallback = repository.openAllFilesAccessFallbackIntent()
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Cấp quyền truy cập tệp") }
                        } else {
                            val junk = state.junk
                            if (junk != null && junk.files.isNotEmpty()) {
                                Text(
                                    "Tìm thấy ${junk.files.size} file rác",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = colors.signalFair
                                )
                                Button(
                                    onClick = viewModel::deleteJunk,
                                    enabled = !state.isScanningJunk,
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Xoá file rác ngay") }
                            }
                            OutlinedButton(
                                onClick = viewModel::scanJunk,
                                enabled = !state.isScanningJunk,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (state.isScanningJunk) "Đang xử lý..." else "Quét file rác") }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.Icon(Icons.Filled.NetworkCheck, contentDescription = null, tint = colors.signalGood)
                            Spacer(Modifier.width(8.dp))
                            Text("Làm mới Wi-Fi", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "Wi-Fi hiện tại: " + if (state.wifiIsOn) "Đang bật" else "Đang tắt",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Từ Android 10 trở lên, hệ thống không cho app bật/tắt Wi-Fi trực tiếp nữa — " +
                                "nút dưới sẽ mở bảng điều khiển Wi-Fi của hệ thống để bạn bật lại nhanh.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedButton(
                            onClick = {
                                context.startActivitySafely(
                                    repository.openWifiPanelIntent(),
                                    fallback = android.content.Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Mở bảng điều khiển Wi-Fi")
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}
