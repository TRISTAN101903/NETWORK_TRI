package com.tristan.network.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceDao {
    @Query("SELECT * FROM known_devices ORDER BY lastSeen DESC")
    fun observeAll(): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM known_devices WHERE macOrIp = :key LIMIT 1")
    suspend fun getByKey(key: String): DeviceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DeviceEntity)

    @Update
    suspend fun update(entity: DeviceEntity)

    @Query("UPDATE known_devices SET customName = :name WHERE macOrIp = :key")
    suspend fun rename(key: String, name: String)

    @Query("UPDATE known_devices SET isFavorite = :fav WHERE macOrIp = :key")
    suspend fun setFavorite(key: String, fav: Boolean)

    @Query("DELETE FROM known_devices WHERE macOrIp = :key")
    suspend fun delete(key: String)
}
