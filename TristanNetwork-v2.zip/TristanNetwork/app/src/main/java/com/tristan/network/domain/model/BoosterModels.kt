package com.tristan.network.domain.model

/** Results from the Device & Wi-Fi speed boost feature (see BoosterRepository). */
sealed class BoosterResult {
    data class MemorySnapshot(
        val totalMb: Long,
        val availableMb: Long,
        val usedPercent: Int,
        val isLowMemory: Boolean
    ) : BoosterResult()

    data class TrimResult(
        val packagesRequested: Int,
        val freedMb: Long
    ) : BoosterResult()
}

/** Battery/performance mode offered in the in-game overlay. Purely a local preset of
 *  this app's own behavior (refresh rates it requests for itself, polling intervals,
 *  overlay animation complexity) — it cannot change what other apps do. */
enum class PerformanceMode(val label: String, val description: String) {
    BALANCED("Cân bằng", "Hiệu năng và pin cân bằng — mặc định khuyến nghị"),
    PERFORMANCE("Hiệu năng cao", "Ưu tiên mượt mà, overlay cập nhật nhanh hơn, hao pin hơn"),
    ULTRA_SAVER("Tiết kiệm pin siêu cao", "Giảm tối đa tần suất cập nhật overlay và animation để kéo dài pin")
}

/** A target refresh rate the overlay lets the user pick. See GameOverlayService for the
 *  real Android capability/limitation notes — this sets what TRISTAN's own overlay window
 *  requests from the display, it does not force other apps' render rate. */
enum class FpsTarget(val fps: Int) {
    FPS_30(30), FPS_60(60), FPS_90(90)
}

/** An app installed on the device that Android itself categorizes as a game. */
data class InstalledGame(
    val packageName: String,
    val label: String,
    val isGame: Boolean = false
)

/** Result of scanning shared storage for safely-deletable junk files. */
data class JunkScanResult(
    val files: List<java.io.File>,
    val totalBytes: Long
)
