package com.tristan.network.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import com.tristan.network.AppContainer

/**
 * Supplies [TristanViewModelFactory] as the default factory for every
 * `viewModel()` call made inside [content], so individual screens don't need
 * to thread the factory through manually.
 */
val LocalTristanViewModelFactory = staticCompositionLocalOf<ViewModelProvider.Factory> {
    error("No TristanViewModelFactory provided")
}

@Composable
fun ViewModelFactoryProvider(container: AppContainer, content: @Composable () -> Unit) {
    val factory = TristanViewModelFactory(container)
    CompositionLocalProvider(LocalTristanViewModelFactory provides factory) {
        content()
    }
}
