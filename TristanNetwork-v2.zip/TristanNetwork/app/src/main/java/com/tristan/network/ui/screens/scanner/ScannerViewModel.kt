package com.tristan.network.ui.screens.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tristan.network.data.network.WifiRepository
import com.tristan.network.data.repository.ScanHistoryRepository
import com.tristan.network.domain.model.ScannedNetwork
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

enum class SortMode { SIGNAL, CHANNEL, NAME }

data class ScannerUiState(
    val isScanning: Boolean = true,
    val networks: List<ScannedNetwork> = emptyList(),
    val sortMode: SortMode = SortMode.SIGNAL,
    val wifiEnabled: Boolean = true,
    val locationEnabled: Boolean = true,
    val connectedBssid: String? = null,
    val lastUpdatedMs: Long = 0L
) {
    /** The least crowded of the three non-overlapping 2.4 GHz channels (1, 6, 11). */
    val suggestedChannel24: Int?
        get() {
            val on24 = networks.filter { it.frequencyMhz in 2400..2500 }
            if (on24.isEmpty()) return null
            return listOf(1, 6, 11).minByOrNull { ch ->
                on24.count { kotlin.math.abs(it.channel - ch) <= 2 }
            }
        }
}

class ScannerViewModel(
    private val wifiRepository: WifiRepository,
    private val scanHistoryRepository: ScanHistoryRepository
) : ViewModel() {

    private val _state = MutableStateFlow(ScannerUiState())
    val state: StateFlow<ScannerUiState> = _state.asStateFlow()

    private var scanJob: Job? = null

    init {
        startScanning()
    }

    /** (Re)starts scanning. Always cancels the previous collector so rescans never pile up. */
    private fun startScanning() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            wifiRepository.scanResultsFlow()
                .catch { _state.value = _state.value.copy(isScanning = false) }
                .collect { networks ->
                    val connected = try {
                        wifiRepository.getCurrentWifiInfo().bssid
                    } catch (_: Exception) {
                        null
                    }
                    _state.value = _state.value.copy(
                        isScanning = false,
                        networks = sorted(networks, _state.value.sortMode),
                        wifiEnabled = wifiRepository.isWifiEnabled(),
                        locationEnabled = wifiRepository.isLocationEnabled(),
                        connectedBssid = connected,
                        lastUpdatedMs = System.currentTimeMillis()
                    )
                    try {
                        scanHistoryRepository.record(networks)
                    } catch (_: Exception) {
                        // History is a nicety; never let it break scanning.
                    }
                }
        }
    }

    fun refreshEnvironment() {
        _state.value = _state.value.copy(
            wifiEnabled = wifiRepository.isWifiEnabled(),
            locationEnabled = wifiRepository.isLocationEnabled()
        )
    }

    fun setSortMode(mode: SortMode) {
        _state.value = _state.value.copy(
            sortMode = mode,
            networks = sorted(_state.value.networks, mode)
        )
    }

    private fun sorted(networks: List<ScannedNetwork>, mode: SortMode): List<ScannedNetwork> =
        when (mode) {
            SortMode.SIGNAL -> networks.sortedByDescending { it.rssiDbm }
            SortMode.CHANNEL -> networks.sortedBy { it.channel }
            SortMode.NAME -> networks.sortedBy { it.ssid.lowercase() }
        }

    fun rescan() {
        _state.value = _state.value.copy(isScanning = true)
        startScanning()
    }
}
