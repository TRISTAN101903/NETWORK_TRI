package com.tristan.network.ui.components

import androidx.compose.runtime.getValue
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.tristan.network.ui.theme.tristanColors
import kotlin.math.sin
import kotlin.random.Random

/**
 * App-wide animated gradient + drifting particle backdrop ("network particles").
 * Lightweight: a handful of circles animated with a single infinite transition,
 * cheap enough for low-end devices while still reading as alive.
 */
@Composable
fun NetworkParticleBackground(
    modifier: Modifier = Modifier,
    particleCount: Int = 18,
    content: @Composable () -> Unit
) {
    val colors = MaterialTheme.tristanColors
    val particles = remember {
        List(particleCount) {
            Particle(
                xSeed = Random.nextFloat(),
                ySeed = Random.nextFloat(),
                radius = Random.nextFloat() * 2.5f + 1f,
                speed = Random.nextFloat() * 0.6f + 0.2f,
                phase = Random.nextFloat() * 6.28f
            )
        }
    }

    val transition = rememberInfiniteTransition(label = "bg")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "t"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.backgroundGradient)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawParticles(particles, t, colors.isDark)
        }
        content()
    }
}

private data class Particle(
    val xSeed: Float,
    val ySeed: Float,
    val radius: Float,
    val speed: Float,
    val phase: Float
)

private fun DrawScope.drawParticles(particles: List<Particle>, t: Float, isDark: Boolean) {
    val w = size.width
    val h = size.height
    val baseAlpha = if (isDark) 0.35f else 0.18f
    particles.forEach { p ->
        val drift = sin((t * 6.28f * p.speed) + p.phase)
        val x = p.xSeed * w
        val y = ((p.ySeed + t * p.speed * 0.15f) % 1f) * h
        val alpha = (baseAlpha * (0.6f + 0.4f * ((drift + 1f) / 2f))).coerceIn(0f, 1f)
        drawCircle(
            color = androidx.compose.ui.graphics.Color(0xFF34E7FF).copy(alpha = alpha),
            radius = p.radius.dp2px(this),
            center = Offset(x + drift * 12f, y)
        )
    }
}

private fun Float.dp2px(scope: DrawScope): Float = this * scope.density
