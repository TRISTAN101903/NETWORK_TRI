package com.tristan.network.ui.components

import androidx.compose.runtime.getValue
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.tristan.network.ui.theme.tristanColors
import kotlin.math.sin

/** Decorative animated waveform, used behind signal-strength and latency readouts. */
@Composable
fun WaveformBackground(modifier: Modifier = Modifier, amplitude: Float = 1f) {
    val colors = MaterialTheme.tristanColors
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing)),
        label = "phase"
    )

    Canvas(modifier = modifier.fillMaxWidth().height(60.dp)) {
        val w = size.width
        val h = size.height
        val midY = h / 2f

        listOf(0.5f to 0.25f, 1f to 0.5f).forEach { (ampMul, alpha) ->
            val path = Path()
            path.moveTo(0f, midY)
            var x = 0f
            while (x <= w) {
                val y = midY + sin((x / w * 4 * Math.PI) + phase) * (h / 2.4) * amplitude * ampMul
                path.lineTo(x, y.toFloat())
                x += 4f
            }
            drawPath(
                path = path,
                color = colors.signalGood.copy(alpha = alpha.toFloat()),
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

/** A single pulsing dot used for "live" / online indicators. */
@Composable
fun SignalPulseDot(modifier: Modifier = Modifier, color: androidx.compose.ui.graphics.Color) {
    val transition = rememberInfiniteTransition(label = "pulseDot")
    val scale by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Restart),
        label = "scale"
    )
    val alpha by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Restart),
        label = "alpha"
    )
    Canvas(modifier = modifier) {
        val r = size.minDimension / 2f
        drawCircle(color = color.copy(alpha = alpha), radius = r * scale, center = Offset(r, r))
        drawCircle(color = color, radius = r * 0.6f, center = Offset(r, r))
    }
}
