# TRISTAN NETWORK — Premium Edition

A native Android app for inspecting/diagnosing Wi-Fi networks you own or administer, boosting your own device's free RAM and refreshing its Wi-Fi link, and an in-game performance overlay — built with Kotlin, Jetpack Compose, and a premium "Liquid Glass" / neon glassmorphism UI with the TRISTAN rocket-T mark and an animated cursive signature.

## Build target: GitHub Codespaces (no Android Studio needed)

This repo includes a `.devcontainer/` so you can build a real `.apk` entirely from GitHub Codespaces:

1. Push this repo to GitHub (or open it as a repo already on GitHub).
2. On the repo page: **Code → Codespaces → Create codespace on main**.
3. Wait for the container to finish `onCreateCommand` (installs the Android SDK — a few minutes, first time only).
4. In the Codespace terminal:
   ```bash
   ./build-apk.sh           # debug APK
   ./build-apk.sh release   # release APK (unsigned)
   ```
5. The built file is printed, e.g. `app/build/outputs/apk/debug/app-debug.apk` — right-click it in the Explorer sidebar and **Download**.

A `.github/workflows/build-apk.yml` is also included: just pushing to `main` builds the debug APK in GitHub Actions and attaches it as a downloadable artifact on the run, if you'd rather not open a Codespace at all.

> This project was written and reviewed in a sandboxed environment with no access to the Android SDK or Google's Maven repository, so it has not been compiled here. It went through two full manual consistency passes (package/import correctness, DI wiring, navigation routes, manifest permissions, Compose-in-Service hosting for the overlay) but a first build in Codespaces may still turn up the usual first-build friction — report back anything that doesn't build and it can be fixed from there.

## What it does

**Wi-Fi diagnostics** (networks you own or are authorized to administer):
- **Dashboard** — SSID/BSSID, signal strength, band/channel, link speed, IP/gateway/DNS, internet status, security type.
- **Wi-Fi Scanner** — nearby networks with RSSI/channel/frequency/security, realtime signal chart, radar scan animation.
- **Network Analyzer** — ping, DNS lookup, latency chart, packet-loss test, HTTP/HTTPS check, legitimate up/download speed test.
- **Local Devices** — LAN discovery via ARP-table / ping-sweep, with nicknames, favorites, online-change tracking.
- **Security Audit** — reads encryption type, scores it, gives recommendations (WPA2/3, disable WPS, strong password, firmware updates, review unknown devices). Never recovers or guesses a password.
- **Router Management** — optional: your router's admin IP + your own admin credentials, over its official HTTP(S) admin API. No bypass of authentication.
- **Lab Mode** — fully synthetic, offline sandbox for exploring the UI against made-up topologies.

**Device & Wi-Fi speed boost** (new):
- Requests the OS trim cached background processes (`ActivityManager` — Android decides per-process what it actually honors; this app doesn't pretend to force-kill anything the OS protects).
- Clears Tristan Network's own app cache (the one thing a non-root app can always clear — another app's cache needs the user's own action in Settings, which this screen deep-links to).
- Best-effort Wi-Fi reconnect, with a one-tap shortcut to the system Wi-Fi panel as the reliable fallback (Android 10+ doesn't let normal apps toggle Wi-Fi directly anymore).

**Game Booster — in-game side overlay** (new):
- A slim handle on the screen's left edge appears automatically when a game you've opted into tracking is in the foreground (detected via Android's standard Usage Access API — the same mechanism Digital Wellbeing uses, not an Accessibility Service).
- Drag it, tap to pull out a "siêu công nghệ" neon glass panel: live Wi-Fi signal/link-speed/ping, battery %, a battery/performance mode (Balanced / Performance / Ultra Power Saving — these govern the overlay's own refresh cadence and animation complexity), an FPS target (30/60/90), and an auto Do-Not-Disturb toggle that silences notification popups while you're in a tracked game.
- **Honest limits, by design:** the FPS picker sets a preferred display-refresh-rate *hint* for TRISTAN's own overlay window — Android does not let a normal, non-root app force another app's internal render rate. Likewise, this feature was deliberately **not** built to hide the overlay from or otherwise evade a game's anti-cheat system — that would help defeat another developer's anti-fraud system in an online game and risk the user's account, so it's out of scope on principle, not an oversight.
- Needs three user-granted permissions, each with an in-app "Cấp quyền" button: Usage Access (detect foreground game), Overlay/"draw over other apps" (show the panel), and Notification Policy Access (auto-DND). None of these are silently assumed — the app only turns the overlay on once you've granted them.

## What it deliberately does not do

No password cracking, brute-force/credential-stuffing, deauthentication/jamming of other devices, router authentication bypass, or anti-cheat-detection evasion — even though some of these were in earlier scope requests for this project. Everything here is read-only inspection or self-device optimization using standard public Android APIs, on networks/devices/games the user already has access to.

## Architecture

- **Kotlin** + **Jetpack Compose** (Material 3), manual DI via `AppContainer` / `TristanViewModelFactory` (no Hilt)
- **MVVM**: `ViewModel` + `StateFlow`
- **Coroutines** throughout (scanning, pinging, discovery, overlay stats loop)
- **Room** for local persistence (saved devices, scan history)
- **DataStore** for settings (theme, booster/game-booster preferences, tracked game list)
- The in-game overlay is a foreground `Service` (`GameOverlayService`) hosting a `ComposeView` added via `WindowManager`, with its own minimal `Lifecycle`/`ViewModelStore`/`SavedStateRegistry` owner (`ComposeOverlayLifecycleOwner`) since it runs outside any Activity
- No root required anywhere. Target/compile SDK 36, minSdk 29, ARM64.

## Privacy

- No network/scan/device data is ever sent to a server — everything stays local (Room/DataStore).
- Wi-Fi passwords are never requested, read, or transmitted.
- `android:allowBackup="false"` + explicit `dataExtractionRules` block cloud/device backup of all local data.
- The in-game overlay only reads this device's own Wi-Fi/battery status and the foreground app's package name (for detecting a tracked game) — it reads nothing from inside other apps.
- The app states plainly, in-app, which Android permissions it uses and why.

## Project structure

```
app/src/main/java/com/tristan/network/
├── MainActivity.kt, TristanApplication.kt, AppContainer.kt
├── data/
│   ├── local/db/        Room entities + DAOs + database
│   ├── local/datastore/ Settings DataStore (incl. Game Booster prefs)
│   └── network/         WifiRepository, NetworkAnalyzer, LocalDeviceDiscovery,
│                         BoosterRepository, GameDetector
├── domain/model/        Plain data models
└── ui/
    ├── theme/           Color/Type/Theme (Liquid Glass + neon tokens)
    ├── components/      GlassCard/NeonGlassCard, RocketLogo, SignatureAnimation,
    │                     TristanBranding, RadarScan, Waveform, particle bg, skeletons
    ├── navigation/       NavGraph + bottom nav + MoreScreen
    ├── overlay/          GameOverlayService, ComposeOverlayLifecycleOwner, OverlayPanelContent
    └── screens/          splash, dashboard, scanner, analyzer, devices, audit,
                           router, lab, settings, booster, gameboost
```

## Branding

`RocketLogo.kt` draws the animated "rocket-T" mark (fuselage + fins built from the letter T, cyan→violet gradient, exhaust flicker) used on the splash screen and Settings/About; `ic_launcher_foreground.xml` is its static adaptive-icon version. `SignatureAnimation.kt` draws an animated cursive "Tristan" signature (stroke-in effect) used alongside the "© TRISTAN Business" copyright line (`TristanBranding.kt`) on the splash screen, Settings, and the overlay panel footer.
