#!/usr/bin/env bash
# One-command APK build, meant to run inside the GitHub Codespace set up by
# .devcontainer/ (which has real internet access to Google's Maven repo,
# unlike a restricted chat sandbox).
#
# Usage:
#   ./build-apk.sh           # debug APK (installable, not for the Play Store)
#   ./build-apk.sh release   # release APK (unsigned — see note below)
set -euo pipefail

VARIANT="${1:-debug}"

if [ ! -f local.properties ]; then
  echo "local.properties not found — did .devcontainer/setup-android-sdk.sh run?"
  echo "If you're not in the Codespace devcontainer, create local.properties with:"
  echo "  sdk.dir=/path/to/your/Android/sdk"
  exit 1
fi

case "$VARIANT" in
  debug)
    ./gradlew assembleDebug
    OUT="app/build/outputs/apk/debug/app-debug.apk"
    ;;
  release)
    ./gradlew assembleRelease
    OUT="app/build/outputs/apk/release/app-release-unsigned.apk"
    echo
    echo "NOTE: this release APK is UNSIGNED. Sign it before installing/distributing:"
    echo "  apksigner sign --ks your.keystore --out app-release-signed.apk ${OUT}"
    ;;
  *)
    echo "Unknown variant '$VARIANT' — use 'debug' or 'release'."
    exit 1
    ;;
esac

echo
if [ -f "$OUT" ]; then
  echo "Built: $OUT"
  echo "Download it from the Codespaces file explorer, or run:"
  echo "  cp \"$OUT\" ~/  "
else
  echo "Build finished but the expected APK was not found at $OUT — check the Gradle output above."
  exit 1
fi
